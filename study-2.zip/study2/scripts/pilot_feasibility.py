"""Technical feasibility pilot (not analyzed): one non-study query, baseline corpus, both models, full 48-resource prompt.
Purpose: confirm context length, latency, schema enforcement and finish_reason before freezing. Not part of the 54 frozen queries."""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(__file__))
import run_study2 as R
q, docs, sched, maps, prompt = R.load()
dept = {}
row = {"block_id": list(maps)[0], "target_doc_id": "DOC_001", "condition": "baseline", "query_id": "PILOT"}
q = {"PILOT": {"query_text": "Which resource would help me understand how musical instruments produce sound?"}}
os.makedirs(os.path.join(R.ROOT, 'pilot'), exist_ok=True)
for m in R.CFG['models']:
    body = R.build_request(row, m, q, docs, maps, prompt); t = time.time()
    res = R.client(300).post(R.URL, json=body); j = res.json() if res.status_code == 200 else {"http": res.status_code, "text": res.text[:500]}
    json.dump({"model": m['label'], "elapsed": time.time() - t, "response": j}, open(os.path.join(R.ROOT, 'pilot', m['label'] + '.json'), 'w'), indent=1)
    if res.status_code == 200:
        c = j['choices'][0]; print(m['label'], round(time.time() - t, 1), 's', j.get('model'), c.get('finish_reason'), j.get('usage'), (c['message'].get('content') or '')[:300].replace('\n', ' '))
    else: print(m['label'], j)
    time.sleep(5)
