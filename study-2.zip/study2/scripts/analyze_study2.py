"""Study 2 prespecified analysis.

Primary endpoint: target resource ranked first (malformed, invalid, abstained, or transport-exhausted = failure).
Contrasts: each GEO condition vs baseline, within each model (6 contrasts, Holm-adjusted).
Inference unit: the 18 target resources (3 queries x 3 repetitions = 9 paired observations each).
Test: exact paired sign-flip permutation over the 18 resource-level mean differences (2^18 assignments).
Interval: resource-cluster bootstrap (10,000 resamples, seed from config), percentile 95% CI; 90% CI for TOST
against the prespecified +/-10 percentage-point equivalence margin.
"""
import csv, json, os, glob, itertools, math, random
from collections import defaultdict
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'study2_config.json')))
OUT = os.path.join(ROOT, 'analysis'); os.makedirs(OUT, exist_ok=True)
GEO = [c for c in CFG['conditions'] if c != 'baseline']
MARGIN = CFG['equivalence_margin_pp'] / 100
dept = {r['doc_id']: r['department_group'] for r in csv.DictReader(open(os.path.join(ROOT, 'corpus', 'document_departments.csv')))}
qtype = {r['query_id']: r['query_type'] for r in csv.DictReader(open(os.path.join(ROOT, 'source', 'main_study_query_set.csv'), encoding='utf-8-sig'))}


def wilson(k, n, z=1.959964):
    if n == 0: return (float('nan'),) * 2
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - h) / d, (c + h) / d)


def load_rows():
    rows = []
    for m in CFG['models']:
        for f in sorted(glob.glob(os.path.join(ROOT, 'runs', m['label'], '*__result.json'))):
            d = json.load(open(f)); s = d['schedule']; mt = d.get('metrics') or {}
            rows.append(dict(model=m['label'], request_id=s['request_id'], block=s['block_id'], query=s['query_id'], rep=int(s['repetition']),
                             condition=s['condition'], target=s['target_doc_id'], qtype=qtype[s['query_id']], status=d['status'],
                             valid_json=mt.get('valid_json', 0), usable=mt.get('selection_usable', 0), first=mt.get('target_first', 0),
                             top3=mt.get('target_top3', 0), rr=mt.get('target_rr3', 0.0), abstain=mt.get('abstain'),
                             first_doc=mt.get('first_doc_id'), comp_first=mt.get('first_same_department_competitor', 0),
                             first_is_study1=int(bool(mt.get('first_doc_id')) and int(mt['first_doc_id'][4:]) <= 18),
                             quote=mt.get('quote_fidelity', 'not_evaluable'), finish=mt.get('finish_reason'),
                             issues='; '.join(mt.get('issues', [])),
                             prompt_tokens=(d.get('usage') or {}).get('prompt_tokens'), completion_tokens=(d.get('usage') or {}).get('completion_tokens')))
    return rows


def resource_diffs(rows, model, cond, metric):
    """Per-resource mean paired difference (cond - baseline) across its 9 (query, repetition) pairs."""
    cell = {(r['block'], r['condition']): r[metric] for r in rows if r['model'] == model}
    per = defaultdict(list)
    for r in rows:
        if r['model'] == model and r['condition'] == 'baseline':
            per[r['target']].append(cell[(r['block'], cond)] - r[metric])
    keys = sorted(per)
    return keys, np.array([np.mean(per[k]) for k in keys]), per


def signflip_p(d):
    obs = abs(d.mean()); n = len(d); cnt = 0; tot = 0
    signs = np.array(list(itertools.product((1, -1), repeat=n)), dtype=np.int8)
    for chunk in np.array_split(signs, 64):
        s = np.abs((chunk * d).mean(axis=1)); cnt += int((s >= obs - 1e-12).sum()); tot += len(chunk)
    return cnt / tot


def bootstrap(d, seed, B=10000):
    rng = np.random.default_rng(seed); idx = rng.integers(0, len(d), size=(B, len(d))); bs = d[idx].mean(axis=1)
    return np.percentile(bs, [2.5, 97.5]), np.percentile(bs, [5, 95])


def holm(ps):
    order = sorted(range(len(ps)), key=lambda i: ps[i]); adj = [0] * len(ps); run = 0
    for k, i in enumerate(order):
        run = max(run, min(1, (len(ps) - k) * ps[i])); adj[i] = run
    return adj


def main():
    rows = load_rows()
    with open(os.path.join(OUT, 'study2_request_level.csv'), 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    res = {"n_requests": len(rows), "models": {}, "contrasts": [], "secondary_contrasts": [], "by_query_type": [], "pooled": []}
    for m in CFG['models']:
        L = m['label']; md = {}
        for c in CFG['conditions']:
            R = [r for r in rows if r['model'] == L and r['condition'] == c]; n = len(R)
            k = sum(r['first'] for r in R); u = [r for r in R if r['usable']]
            qf = [r for r in u if r['quote'] in ('pass', 'fail')]
            md[c] = dict(n=n, target_first=k, target_first_rate=k / n, target_first_wilson=wilson(k, n),
                         target_top3=sum(r['top3'] for r in R), mrr3=float(np.mean([r['rr'] for r in R])),
                         valid_json=sum(r['valid_json'] for r in R), usable=len(u), abstained=sum(1 for r in R if r['abstain'] is True),
                         transport_exhausted=sum(1 for r in R if r['status'] != 'response'),
                         same_dept_competitor_first=sum(r['comp_first'] for r in R),
                         other_dept_first=sum(1 for r in u if r['first_doc'] != r['target'] and not r['comp_first']),
                         quote_fail=sum(1 for r in qf if r['quote'] == 'fail'), quote_evaluable=len(qf),
                         finish_not_stop=sum(1 for r in R if r['valid_json'] and r['finish'] != 'stop'))
        res['models'][L] = md
    # primary contrasts
    seed = CFG['bootstrap_seed']; prim = []
    for mi, m in enumerate(CFG['models']):
        for ci, c in enumerate(GEO):
            keys, d, per = resource_diffs(rows, m['label'], c, 'first')
            ci95, ci90 = bootstrap(d, seed + 10 * mi + ci)
            prim.append(dict(model=m['label'], contrast=f'{c} - baseline', n_resources=len(d), n_pairs=sum(len(v) for v in per.values()),
                             diff_pp=100 * d.mean(), ci95_pp=list(100 * ci95), ci90_pp=list(100 * ci90), p_signflip=signflip_p(d),
                             equivalent_within_margin=bool(ci90[0] > -MARGIN and ci90[1] < MARGIN),
                             resources_up=int((d > 0).sum()), resources_down=int((d < 0).sum()), resources_tied=int((d == 0).sum()),
                             per_resource_pp={k: 100 * float(v) for k, v in zip(keys, d)}))
    for p, a in zip(prim, holm([p['p_signflip'] for p in prim])): p['p_holm'] = a
    res['contrasts'] = prim
    # secondary contrasts (descriptive inference, unadjusted)
    for metric in ('top3', 'rr', 'comp_first', 'valid_json'):
        for mi, m in enumerate(CFG['models']):
            for ci, c in enumerate(GEO):
                keys, d, _ = resource_diffs(rows, m['label'], c, metric); ci95, _ = bootstrap(d, seed + 100 + 10 * mi + ci)
                res['secondary_contrasts'].append(dict(metric=metric, model=m['label'], contrast=f'{c} - baseline', diff=float(d.mean()),
                                                       ci95=list(ci95), p_signflip=signflip_p(d)))
    # by query type (descriptive)
    for m in CFG['models']:
        for t in ('topic', 'learner_intent', 'task_oriented'):
            for c in CFG['conditions']:
                R = [r for r in rows if r['model'] == m['label'] and r['condition'] == c and r['qtype'] == t]
                if R: res['by_query_type'].append(dict(model=m['label'], query_type=t, condition=c, n=len(R), target_first=sum(r['first'] for r in R)))
    # pooled-model sensitivity: average the two models' resource-level differences
    if len(CFG['models']) > 1:
        for ci, c in enumerate(GEO):
            ds = [resource_diffs(rows, m['label'], c, 'first')[1] for m in CFG['models']]; d = np.mean(ds, axis=0)
            ci95, ci90 = bootstrap(d, seed + 200 + ci)
            res['pooled'].append(dict(contrast=f'{c} - baseline', diff_pp=100 * d.mean(), ci95_pp=list(100 * ci95), ci90_pp=list(100 * ci90),
                                      p_signflip=signflip_p(d), equivalent_within_margin=bool(ci90[0] > -MARGIN and ci90[1] < MARGIN)))
    # per-resource baseline difficulty and displacement sources
    disp = defaultdict(int)
    for r in rows:
        if r['usable'] and not r['first']: disp[(r['model'], r['condition'], 'competitor' if r['first_doc'] and int(r['first_doc'][4:]) > 18 else 'study1_doc')] += 1
    res['displacement_sources'] = [dict(model=k[0], condition=k[1], source=k[2], n=v) for k, v in sorted(disp.items())]
    json.dump(res, open(os.path.join(OUT, 'study2_results.json'), 'w'), indent=1, default=float)
    for p in prim:
        print(f"{p['model']} {p['contrast']:32s} {p['diff_pp']:+6.2f} pp 95% [{p['ci95_pp'][0]:+.2f},{p['ci95_pp'][1]:+.2f}] 90% [{p['ci90_pp'][0]:+.2f},{p['ci90_pp'][1]:+.2f}] p={p['p_signflip']:.4f} holm={p['p_holm']:.4f} equiv={p['equivalent_within_margin']}")
    for L, md in res['models'].items():
        for c, v in md.items(): print(L, c, v['target_first'], '/', v['n'], 'valid', v['valid_json'], 'usable', v['usable'], 'compfirst', v['same_dept_competitor_first'], 'qfail', v['quote_fail'], '/', v['quote_evaluable'])
    for p in res['pooled']: print('pooled', p['contrast'], round(p['diff_pp'], 2), p['ci95_pp'], p['ci90_pp'], p['p_signflip'], p['equivalent_within_margin'])


if __name__ == '__main__':
    main()
