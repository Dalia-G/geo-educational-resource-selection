"""Study 2 runner: competitive, target-only GEO with same-department competitors and schema-enforced JSON.

Each request presents all 48 resources (R01-R48). Only the target resource of the query is rendered in the
assigned condition; the other 47 resources are always shown in their baseline form. The label mapping of a block
(query x repetition) is shared by all four conditions and both models.

Execution policy (fixed before execution):
  * every input file is verified against the frozen SHA-256 manifest before any request is sent;
  * at least 5 s between consecutive request starts per model;
  * the runner stops between requests after RUN_BUDGET_SECONDS and is restarted by the driver (resume from checkpoints);
  * up to 3 retries of the identical request for transport errors (connection, timeout, 408, 429, 5xx);
  * no content-repair retries: malformed or invalid outputs are scored as failures;
  * every attempt and raw response is preserved; the run stops if the returned model identifier changes.
The API key is never read by this script; it is injected by the sandbox credential proxy.
"""
import csv, json, hashlib, os, re, sys, time, threading
from datetime import datetime, timezone
sys.path.insert(0, os.path.dirname(__file__))
from http_client import client

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, 'study2_config.json')))
URL = CFG['base_url'].rstrip('/') + '/chat/completions'
START = time.monotonic()
BUDGET = float(os.environ.get('RUN_BUDGET_SECONDS', '1e12'))  # credential grants last 15 min; the driver restarts the runner


def now(): return datetime.now(timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def save(p, d):
    tmp = p + '.tmp'; json.dump(d, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1); os.replace(tmp, p)
def stop(msg): print('STOP:', msg, flush=True); sys.exit(1)
def normalize(t): return ' '.join(t.split())


def verify_inputs():
    frozen = json.load(open(os.path.join(ROOT, 'freeze', 'frozen_manifest.json')))
    for item in frozen['files']:
        p = os.path.join(ROOT, item['path'])
        if sha(open(p, 'rb').read()) != item['sha256']: stop('Hash mismatch: ' + item['path'])
    return frozen


def load():
    q = {r['query_id']: r for r in csv.DictReader(open(os.path.join(ROOT, 'source', 'main_study_query_set.csv'), encoding='utf-8-sig'))}
    docs = {c: {} for c in CFG['conditions']}
    for c in CFG['conditions']:
        for i in range(1, 49):
            d = f'DOC_{i:03d}'
            docs[c][d] = open(os.path.join(ROOT, 'corpus', c, f'{d}_{c}.md'), encoding='utf-8-sig').read()
    sched = list(csv.DictReader(open(os.path.join(ROOT, 'schedule', 'study2_schedule.csv'))))
    maps = json.load(open(os.path.join(ROOT, 'schedule', 'study2_label_mappings.json')))
    prompt = open(os.path.join(ROOT, 'system_prompt_study2.txt'), encoding='utf-8').read()
    if len(q) != 54 or len(sched) != 1296 or len({r['request_id'] for r in sched}) != 1296 or len(maps) != 162: stop('Inventory check failed')
    return q, docs, sched, maps, prompt


def shown_documents(target, condition, docs):
    """Document text actually shown: target in the assigned condition, everything else baseline."""
    return {d: (docs[condition][d] if d == target else docs['baseline'][d]) for d in docs['baseline']}


def schema():
    ids = [f'R{i:02d}' for i in range(1, 49)]
    return {"type": "object", "additionalProperties": False,
            "properties": {"abstain": {"type": "boolean"},
                           "ranked_resource_ids": {"type": "array", "items": {"type": "string", "enum": ids}, "minItems": 3, "maxItems": 3},
                           "answer": {"type": "string"},
                           "cited_resource_ids": {"type": "array", "items": {"type": "string", "enum": ids}},
                           "evidence_quotes": {"type": "array", "minItems": 1, "maxItems": 2, "items": {"type": "object", "additionalProperties": False,
                               "properties": {"resource_id": {"type": "string", "enum": ids}, "quote": {"type": "string"}},
                               "required": ["resource_id", "quote"]}}},
            "required": ["abstain", "ranked_resource_ids", "answer", "cited_resource_ids", "evidence_quotes"]}


def build_request(row, model, q, docs, maps, prompt):
    mapping = maps[row['block_id']]
    shown = shown_documents(row['target_doc_id'], row['condition'], docs)
    resources = '\n\n'.join(f'<resource id="{rid}">\n{shown[d]}\n</resource>' for rid, d in mapping.items())
    user = 'EDUCATIONAL QUERY\n' + q[row['query_id']]['query_text'].strip() + '\n\nRESOURCES\n' + resources
    body = {"model": model['model_id'], "messages": [{"role": "system", "content": prompt}, {"role": "user", "content": user}],
            "temperature": CFG['temperature'], "top_p": CFG['top_p'], "max_tokens": CFG['max_tokens'], "stream": False}
    body.update(model.get('extra_body', {}))
    if model['structured_output'] == 'response_format_json_schema':
        body['response_format'] = {"type": "json_schema", "json_schema": {"name": "resource_selection", "schema": schema(), "strict": True}}
    elif model['structured_output'] == 'nvext_guided_json':
        body['nvext'] = {"guided_json": schema()}
    return body


def assess(raw, mapping, shown, target, dept_of):
    r = {"valid_json": 0, "selection_usable": 0, "target_first": 0, "target_top3": 0, "target_rr3": 0.0, "target_rank": None,
         "abstain": None, "ranked_doc_ids": [], "first_doc_id": None, "first_same_department_competitor": 0,
         "quote_fidelity": "not_evaluable", "finish_reason": None, "issues": []}
    iss = r['issues']
    ch = (raw.get('choices') or [None])[0]
    if not ch: iss.append('No response choices'); return r
    r['finish_reason'] = ch.get('finish_reason')
    content = (ch.get('message') or {}).get('content')
    try: data = json.loads(content)
    except (TypeError, ValueError): iss.append('Response is not valid JSON'); return r
    if not isinstance(data, dict): iss.append('Response JSON is not an object'); return r
    r['valid_json'] = 1
    ab, ranked, cited, quotes, ans = (data.get(k) for k in ('abstain', 'ranked_resource_ids', 'cited_resource_ids', 'evidence_quotes', 'answer'))
    if type(ab) is not bool: iss.append('Invalid abstain field'); return r
    r['abstain'] = ab
    if r['finish_reason'] != 'stop': iss.append('Finish reason is not stop'); return r
    if ab:
        iss.append('Abstained'); return r
    if not (isinstance(ranked, list) and len(ranked) == 3 and all(x in mapping for x in ranked) and len(set(ranked)) == 3):
        iss.append('Ranking must contain three distinct valid IDs'); return r
    r['selection_usable'] = 1
    rd = [mapping[x] for x in ranked]; r['ranked_doc_ids'] = rd; r['first_doc_id'] = rd[0]
    if target in rd:
        k = rd.index(target) + 1; r.update(target_rank=k, target_first=int(k == 1), target_top3=1, target_rr3=1 / k)
    if rd[0] != target and dept_of[rd[0]] == dept_of[target]: r['first_same_department_competitor'] = 1
    if not isinstance(ans, str) or not ans.strip() or len(ans.split()) > 150: iss.append('Answer missing, empty, or over 150 words')
    qi = []
    if not isinstance(quotes, list) or not 1 <= len(quotes) <= 2: qi.append('Expected one or two evidence quotes')
    else:
        for it in quotes:
            t = it.get('quote') if isinstance(it, dict) else None
            if not isinstance(it, dict) or it.get('resource_id') != ranked[0]: qi.append('Quote not attributed to first-ranked resource'); continue
            if not isinstance(t, str) or not t.strip(): qi.append('Quote missing or empty'); continue
            if len(t.split()) > 50: qi.append('Quote exceeds 50 words')
            if normalize(t) not in normalize(shown[rd[0]]): qi.append('Quote not found after whitespace normalization')
    iss.extend(qi); r['quote_fidelity'] = 'fail' if qi else 'pass'
    return r


def run_model(model, q, docs, sched, maps, prompt, dept_of):
    out = os.path.join(ROOT, 'runs', model['label']); os.makedirs(out, exist_ok=True)
    http = client(CFG['timeout_seconds']); identity = None; last = 0.0
    idp = os.path.join(out, 'observed_model.json')
    if os.path.exists(idp): identity = json.load(open(idp))['returned_model']
    rows = [r for r in sched if r['model_label'] == model['label']]
    for n, row in enumerate(rows, 1):
        if time.monotonic() - START > BUDGET: print(f"[{model['label']}] session budget reached; resume later", flush=True); return
        rid = row['request_id']; resp = os.path.join(out, rid + '__result.json')
        if os.path.exists(resp): continue
        body = build_request(row, model, q, docs, maps, prompt); h = sha(json.dumps(body, sort_keys=True).encode())
        rq = os.path.join(out, rid + '__request.json')
        if os.path.exists(rq) and json.load(open(rq))['request_sha256'] != h: stop('Saved request differs: ' + rid)
        save(rq, {"schedule": row, "request_sha256": h, "request": body})
        done = False
        for a in range(1, 5):
            ap = os.path.join(out, f'{rid}__attempt_{a}.json')
            if os.path.exists(ap):
                rec = json.load(open(ap))
                if rec['status'] == 'started':   # process ended while waiting for a reply: logged as a transport failure
                    rec.update(status='transient_error', error_type='interrupted_by_session_budget', finished_utc=now()); save(ap, rec)
            else:
                time.sleep(max(0, CFG['min_seconds_between_requests'] - (time.monotonic() - last)))
                rec = {"request_id": rid, "attempt": a, "status": "started", "started_utc": now()}; save(ap, rec)
                last = time.monotonic(); t0 = time.monotonic()
                try:
                    res = http.post(URL, json=body)
                    if res.status_code == 200:
                        rec.update(status='response', response=res.json())
                    else:
                        transient = res.status_code in (408, 429) or 500 <= res.status_code <= 599
                        st = 'auth_error' if res.status_code == 401 else ('transient_error' if transient else 'fatal_error')
                        rec.update(status=st, http_status=res.status_code, error_body=res.text[:2000])
                except Exception as e:
                    rec.update(status='transient_error', error_type=type(e).__name__, error=str(e)[:500])
                rec.update(finished_utc=now(), elapsed_seconds=time.monotonic() - t0); save(ap, rec)
                if rec['status'] == 'auth_error': print(f"[{model['label']}] credential grant expired; session ends, attempt logged as transport failure", flush=True); return
            if rec['status'] == 'fatal_error': stop(f"Fatal API error for {rid}: {rec.get('http_status')} {rec.get('error_body','')[:200]}")
            if rec['status'] == 'response':
                raw = rec['response']; rm = raw.get('model')
                if not rm: stop('No returned model identifier')
                if identity is None: identity = rm; save(idp, {"returned_model": rm, "first_seen_utc": now()})
                elif rm != identity: stop('Returned model identifier changed')
                shown = shown_documents(row['target_doc_id'], row['condition'], docs)
                m = assess(raw, maps[row['block_id']], shown, row['target_doc_id'], dept_of)
                save(resp, {"schedule": row, "status": "response", "attempt": a, "metrics": m, "usage": raw.get('usage'), "returned_model": rm})
                print(f"[{model['label']} {n}/{len(rows)}] {rid} target_first={m['target_first']} valid={m['valid_json']} issues={m['issues']}", flush=True)
                done = True; break
            if a < 4: time.sleep((15, 30, 60)[a - 1])
        if not done:
            save(resp, {"schedule": row, "status": "transport_exhausted", "attempts": 4}); print('  transport exhausted', rid, flush=True)


def main():
    frozen = verify_inputs()
    q, docs, sched, maps, prompt = load()
    meta = {r['doc_id']: r['department_group'] for r in csv.DictReader(open(os.path.join(ROOT, 'corpus', 'document_departments.csv')))}
    labels = sys.argv[1:] or [m['label'] for m in CFG['models']]
    threads = [threading.Thread(target=run_model, args=(m, q, docs, sched, maps, prompt, meta)) for m in CFG['models'] if m['label'] in labels]
    print('Frozen manifest verified:', frozen['freeze_utc'], '| starting', labels, now(), flush=True)
    for t in threads: t.start()
    for t in threads: t.join()
    print('Finished', now(), flush=True)


if __name__ == '__main__':
    main()
