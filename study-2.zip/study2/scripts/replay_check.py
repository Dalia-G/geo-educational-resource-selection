"""Re-score every archived raw response with the runner's scoring function and compare with stored metrics."""
import json, glob, os, sys, csv
sys.path.insert(0, os.path.dirname(__file__))
import run_study2 as R
q, docs, sched, maps, prompt = R.load()
dept = {r['doc_id']: r['department_group'] for r in csv.DictReader(open(os.path.join(R.ROOT, 'corpus', 'document_departments.csv')))}
n = mism = 0; models = {}; attempts = {}; exhausted = 0; body_mism = 0
for f in sorted(glob.glob(os.path.join(R.ROOT, 'runs', '*', '*__result.json'))):
    d = json.load(open(f)); s = d['schedule']; rid = s['request_id']; base = f[:-len('__result.json')]
    req = json.load(open(base + '__request.json'))
    m = next(x for x in R.CFG['models'] if x['label'] == s['model_label'])
    if req['request'] != R.build_request(s, m, q, docs, maps, prompt): body_mism += 1
    if d['status'] != 'response': exhausted += 1; continue
    raw = json.load(open(f"{base}__attempt_{d['attempt']}.json"))['response']
    new = R.assess(raw, maps[s['block_id']], R.shown_documents(s['target_doc_id'], s['condition'], docs), s['target_doc_id'], dept)
    n += 1; mism += int(new != d['metrics']); models.setdefault(s['model_label'], set()).add(raw.get('model'))
    attempts[d['attempt']] = attempts.get(d['attempt'], 0) + 1
out = {"results_rescored": n, "metric_mismatches": mism, "request_bodies_rebuilt_mismatch": body_mism, "transport_exhausted": exhausted,
       "returned_model_ids": {k: sorted(v) for k, v in models.items()}, "successful_attempt_number_counts": attempts}
json.dump(out, open(os.path.join(R.ROOT, 'analysis', 'replay_check.json'), 'w'), indent=1); print(out)
