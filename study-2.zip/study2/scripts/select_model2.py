"""Prespecified second-model selection: first non-NVIDIA candidate (fixed order) returning schema-valid JSON in 5/5
technical test calls (non-study fruit prompt, response_format json_schema, study decoding settings). All outputs logged."""
import json, time, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from http_client import client
from datetime import datetime, timezone
exec(open(os.path.join(os.path.dirname(__file__),'tech_test.py')).read().split('for model in')[0].split('C=client(120)')[1])
C = client(120); CAND = ['google/gemma-4-31b-it','deepseek-ai/deepseek-v4.1-flash','moonshotai/kimi-k2.6','mistralai/mistral-large-2-instruct','z-ai/glm-5.3-flash','minimaxai/minimax-m3.1-flash','openai/gpt-oss-20b']
log = {"rule": __doc__, "started_utc": datetime.now(timezone.utc).isoformat(), "candidates": CAND, "trials": [], "selected": None}
for model in CAND:
    ok = 0
    for i in range(5):
        body = {"model": model, "messages": msgs, "temperature": 1, "top_p": 0.95, "max_tokens": 600,
                "response_format": {"type": "json_schema", "json_schema": {"name": "selection", "schema": SCHEMA, "strict": True}}}
        t = {"model": model, "call": i + 1}
        try:
            r = C.post("https://integrate.api.nvidia.com/v1/chat/completions", json=body, timeout=120); t["http"] = r.status_code
            if r.status_code == 200:
                j = r.json(); c = j["choices"][0]["message"].get("content") or ""; t.update(returned_model=j.get("model"), content=c, finish=j["choices"][0].get("finish_reason"))
                o = json.loads(c); v = isinstance(o, dict) and all(k in o for k in SCHEMA["required"]) and isinstance(o["ranked_resource_ids"], list) and len(o["ranked_resource_ids"]) == 3 and all(x in ["R01","R02","R03","R04"] for x in o["ranked_resource_ids"])
                t["schema_valid"] = bool(v)
            else: t.update(schema_valid=False, error=r.text[:300])
        except Exception as e: t.update(schema_valid=False, error=str(e)[:300])
        log["trials"].append(t); print(model, i + 1, t.get("http"), t["schema_valid"], (t.get("content") or t.get("error",""))[:80].replace("\n"," "), flush=True)
        if not t["schema_valid"]: break
        ok += 1; time.sleep(3)
    if ok == 5: log["selected"] = model; break
log["finished_utc"] = datetime.now(timezone.utc).isoformat()
json.dump(log, open(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'source', 'model2_selection_log.json'), 'w'), indent=1)
print("SELECTED", log["selected"])
