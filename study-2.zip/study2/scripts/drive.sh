#!/bin/bash
# Restart the runner in sessions shorter than the 15-minute credential grant until all 1,296 results exist.
cd "$(dirname "$0")/.."
H="$1"
while [ "$(ls runs/M1/*__result.json runs/M2/*__result.json 2>/dev/null | wc -l)" -lt 1296 ]; do
  RUN_BUDGET_SECONDS=500 pplx credentials run "$H" -- python3 scripts/run_study2.py || { echo "runner exited non-zero $(date -u)"; sleep 60; }
  if tail -n 30 logs/run.log | grep -q '^STOP:'; then echo "Stopped by runner rule"; exit 1; fi
done
echo "ALL DONE $(date -u)"
