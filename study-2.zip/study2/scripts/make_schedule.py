"""Study 2 schedule: 54 queries x 3 repetitions x 4 conditions x 2 models = 1296 requests.
Block = (query, repetition). One random label mapping R01-R48 per block, shared by all conditions and both models.
Condition order randomised independently per (model, block). Seed fixed before execution."""
import csv, json, random, os, hashlib
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cfg = json.load(open(os.path.join(ROOT, 'study2_config.json')))
rng = random.Random(cfg['schedule_seed'])
queries = list(csv.DictReader(open(os.path.join(ROOT, 'source', 'main_study_query_set.csv'), encoding='utf-8-sig')))
docs = [f'DOC_{i:03d}' for i in range(1, 49)]
mappings, rows = {}, []
for q in queries:
    orders = set()
    for rep in (1, 2, 3):
        while True:
            perm = docs[:]; rng.shuffle(perm)
            if tuple(perm) not in orders: orders.add(tuple(perm)); break
        block = f"{q['query_id']}__rep{rep}"
        mappings[block] = {f'R{i+1:02d}': d for i, d in enumerate(perm)}
blocks = list(mappings)
for m in cfg['models']:
    border = blocks[:]; rng.shuffle(border)
    for block in border:
            q = next(x for x in queries if x['query_id'] == block.split('__')[0]); rep = int(block[-1]); conds = cfg['conditions'][:]; rng.shuffle(conds)
            for pos, c in enumerate(conds):
                rows.append(dict(request_id=f"{m['label']}__{block}__{c}", model_label=m['label'], block_id=block, query_id=q['query_id'],
                                 repetition=rep, condition=c, target_doc_id=q['primary_doc_id'], order_in_block=pos + 1))
# interleave models so both progress at similar times; keep block contiguity within model
for i, r in enumerate(rows): r['sequence'] = i + 1
with open(os.path.join(ROOT, 'schedule', 'study2_schedule.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
json.dump(mappings, open(os.path.join(ROOT, 'schedule', 'study2_label_mappings.json'), 'w'), indent=1)
print(len(rows), 'requests;', len(mappings), 'blocks')
