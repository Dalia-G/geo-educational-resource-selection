import json, time, sys
sys.path.insert(0,'scripts')
from http_client import client
C=client(120)
SCHEMA = {"type":"object","properties":{"abstain":{"type":"boolean"},"ranked_resource_ids":{"type":"array","items":{"type":"string","enum":["R01","R02","R03","R04"]},"minItems":3,"maxItems":3},
 "answer":{"type":"string"},"cited_resource_ids":{"type":"array","items":{"type":"string"}},"evidence_quotes":{"type":"array","items":{"type":"object","properties":{"resource_id":{"type":"string"},"quote":{"type":"string"}},"required":["resource_id","quote"]}}},
 "required":["abstain","ranked_resource_ids","answer","cited_resource_ids","evidence_quotes"]}
msgs=[{"role":"system","content":"Rank three fruit resources for the query. Return JSON."},{"role":"user","content":"QUERY: a sour citrus fruit\nR01: Lemon, a sour yellow citrus fruit.\nR02: Banana, a sweet tropical fruit.\nR03: Lime, a green \"tart\" citrus.\nR04: Apple, a crisp fruit."}]
for model in sys.argv[1:]:
  for mode in ["response_format","nvext"]:
    body={"model":model,"messages":msgs,"temperature":1,"top_p":0.95,"max_tokens":600}
    if mode=="response_format": body["response_format"]={"type":"json_schema","json_schema":{"name":"selection","schema":SCHEMA,"strict":True}}
    else: body["nvext"]={"guided_json":SCHEMA}
    if "nemotron-3" in model: body["chat_template_kwargs"]={"enable_thinking":False}
    t=time.time()
    try:
      r=C.post("https://integrate.api.nvidia.com/v1/chat/completions",json=body,timeout=120)
      if r.status_code!=200: print(model,mode,"HTTP",r.status_code,r.text[:150]); continue
      j=r.json(); c=j["choices"][0]["message"].get("content") or ""
      try: o=json.loads(c); ok="VALID" if isinstance(o.get("ranked_resource_ids"),list) and len(o["ranked_resource_ids"])==3 else "VALID-BADRANK"
      except Exception: ok="INVALID"
      print(model,mode,ok,round(time.time()-t,1),"s",j.get("model"),repr(c[:90]))
    except Exception as e: print(model,mode,"ERR",str(e)[:120])
    time.sleep(3)
