"""Build the Study 2 corpus: 18 Study 1 baselines (copied byte-for-byte) + 30 same-department competitors
taken from the MIT Learn public catalog API (platform=ocw). Applies the Study 1 baseline template."""
import json, re, html, hashlib, os, shutil, glob, csv, sys
sys.path.insert(0, os.path.dirname(__file__))
from geo_transform import NL, parse_baseline, TRANSFORMS
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAT = json.load(open(os.path.join(ROOT, 'source', 'ocw_catalog_raw.json')))
COMPETITORS = [  # (doc_id, readable_id, department_group, closest Study 1 target)
 ('DOC_019','6.100L+fall_2022','EECS','DOC_001'), ('DOC_020','6.0002+fall_2016','EECS','DOC_001'),
 ('DOC_021','6.046J+spring_2015','EECS','DOC_007'), ('DOC_022','6.1200J+spring_2024','EECS','DOC_007'),
 ('DOC_023','6.033+spring_2018','EECS','DOC_008'),
 ('DOC_024','18.700+fall_2013','Mathematics','DOC_002'), ('DOC_025','18.065+spring_2018','Mathematics','DOC_002'),
 ('DOC_026','18.600+fall_2019','Mathematics','DOC_009'), ('DOC_027','18.650+fall_2016','Mathematics','DOC_009'),
 ('DOC_028','18.310+fall_2013','Mathematics','DOC_010'),
 ('DOC_029','8.012+fall_2008','Physics','DOC_003'), ('DOC_030','8.223+january-iap_2017','Physics','DOC_003'),
 ('DOC_031','8.09+fall_2014','Physics','DOC_011'), ('DOC_032','8.022+fall_2004','Physics','DOC_012'),
 ('DOC_033','8.07+fall_2012','Physics','DOC_012'),
 ('DOC_034','7.013+spring_2018','Biology','DOC_004'), ('DOC_035','7.016+fall_2018','Biology','DOC_004'),
 ('DOC_036','7.15+spring_2015','Biology','DOC_013'), ('DOC_037','7.05+spring_2020','Biology','DOC_013'),
 ('DOC_038','9.01+fall_2007','Biology','DOC_014'),
 ('DOC_039','5.112+fall_2005','Chemistry','DOC_005'), ('DOC_040','3.091+fall_2018','Chemistry','DOC_005'),
 ('DOC_041','5.13+fall_2006','Chemistry','DOC_015'), ('DOC_042','5.60+spring_2008','Chemistry','DOC_016'),
 ('DOC_043','5.62+spring_2008','Chemistry','DOC_016'),
 ('DOC_044','2.008+spring_2025','Mechanical Engineering','DOC_006'), ('DOC_045','2.12+fall_2005','Mechanical Engineering','DOC_006'),
 ('DOC_046','2.002+spring_2004','Mechanical Engineering','DOC_017'), ('DOC_047','2.72+spring_2009','Mechanical Engineering','DOC_017'),
 ('DOC_048','2.06+spring_2013','Mechanical Engineering','DOC_018'),
]
BROAD = {'Science','Engineering','Mathematics','Business','Social Science','Humanities','Fine Arts','Health and Medicine',
         'Energy','Teaching and Education','Physics','Chemistry','Biology','Computer Science'}

def clean_desc(raw):
    t = html.unescape(raw or '')
    t = re.sub(r'(?i)<\s*br\s*/?>', '\n', t)
    t = re.sub(r'(?i)</p\s*>', '\n\n', t)
    t = re.sub(r'<[^>]+>', '', t).replace('\xa0', ' ')
    paras = [re.sub(r'[ \t]+', ' ', p).strip() for p in re.split(r'\n\s*\n', t)]
    paras = [p for p in paras if p]
    return '\n\n'.join(paras)

def record(rid):
    x = [c for c in CAT if c['readable_id'] == rid]
    assert len(x) == 1, rid
    x = x[0]
    num = [n['value'] for n in x['course']['course_numbers'] if n['listing_type'] == 'primary'][0]
    run = [r for r in x['runs'] if r['id'] == x['best_run_id']] or x['runs']
    run = run[0]
    term = f"{run['semester']} {run['year']}"
    levels = sorted({l['name'] for r in x['runs'] for l in r['level']})
    depts = [d['name'] for d in x['departments']]
    topics = [t for t in x['ocw_topics'] if t not in BROAD] or [t for t in x['ocw_topics'] if t not in {'Science','Engineering'}]
    return dict(num=num, title=x['title'].strip(), dept='; '.join(depts), level='; '.join(levels), term=term,
                desc=clean_desc(x['description']).replace('\n', NL), topics=', '.join(topics), url=x['url'])

def main():
    out = os.path.join(ROOT, 'corpus'); manifest = []
    for c in TRANSFORMS: os.makedirs(os.path.join(out, c), exist_ok=True)
    # Study 1 documents copied byte-for-byte
    for f in sorted(glob.glob(os.path.join(ROOT, 'source', 'study1_corpus', '*', '*.md'))):
        cond = os.path.basename(os.path.dirname(f)); dst = os.path.join(out, cond, os.path.basename(f)); shutil.copyfile(f, dst)
    meta = []
    for doc, rid, grp, near in COMPETITORS:
        d = record(rid)
        for c, fn in TRANSFORMS.items():
            p = os.path.join(out, c, f'{doc}_{c}.md')
            open(p, 'w', encoding='utf-8', newline='').write(fn(d) + NL)
        meta.append(dict(doc_id=doc, readable_id=rid, course_number=d['num'], title=d['title'], department=d['dept'],
                         department_group=grp, closest_study1_target=near, level=d['level'], term=d['term'], source_url=d['url'],
                         description_words=len(d['desc'].split())))
    with open(os.path.join(ROOT, 'corpus', 'competitor_metadata.csv'), 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(meta[0])); w.writeheader(); w.writerows(meta)
    for f in sorted(glob.glob(os.path.join(out, '*', '*.md'))):
        manifest.append(dict(path=os.path.relpath(f, ROOT).replace(os.sep, '/'), sha256=hashlib.sha256(open(f, 'rb').read()).hexdigest()))
    json.dump(manifest, open(os.path.join(ROOT, 'corpus', 'corpus_manifest.json'), 'w'), indent=1)
    print(len(manifest), 'files')
main()
