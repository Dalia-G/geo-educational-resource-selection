"""Deterministic GEO transformations (template-based). Reproduces the Study 1 corpus byte-for-byte."""
import re
NL = "\r\n"

def parse_baseline(text):
    lines = text.replace("\r\n", "\n").split("\n")
    m = re.match(r"# (.+?): (.+)$", lines[0])
    num, title = m.group(1), m.group(2)
    fields = {}
    for key in ("Department", "Level", "Term"):
        for ln in lines:
            if ln.startswith(key + ": "):
                fields[key] = ln[len(key) + 2:]
    body = "\n".join(lines)
    desc = body.split("Description:\n", 1)[1].split("\n\nTopics:\n", 1)[0]
    topics = body.split("Topics:\n", 1)[1].strip("\n")
    return dict(num=num, title=title, dept=fields["Department"], level=fields["Level"], term=fields["Term"], desc=desc.replace("\n", NL), topics=topics)

def baseline(d):
    return NL.join([f"# {d['num']}: {d['title']}", "", f"Department: {d['dept']}", f"Level: {d['level']}", f"Term: {d['term']}", "",
                    "Description:", d["desc"], "", "Topics:", d["topics"]])

def _entity(d):
    return [f"# Course: {d['title']}", "", f"Course number: {d['num']}", "Institution: Massachusetts Institute of Technology",
            "Provider: MIT OpenCourseWare", f"Department: {d['dept']}", f"Academic level: {d['level']}", f"Term: {d['term']}",
            "Resource type: Open educational course page", "", "Course description:", d["desc"], "", "Covered topics:"] + \
           [f"- {t.strip()}" for t in d["topics"].split(", ")]

def _faq_pairs(d, cover=True):
    p = [("What course is this?", f"{d['num']} {d['title']} is an MIT OpenCourseWare course in {d['dept']}."),
         ("What academic level is the course?", f"The course is listed as {d['level']} and was taught in {d['term']}.")]
    if cover: p.append(("What does the course cover?", d["desc"]))
    p.append(("What topics are included?", d["topics"]))
    return p

def entity_structure_geo(d):
    return NL.join(_entity(d))

def faq_geo(d):
    out = [f"# {d['num']}: {d['title']}", ""]
    for q, a in _faq_pairs(d): out += [f"## {q}", "", a, ""]
    return NL.join(out[:-1])

def full_geo(d):
    out = _entity(d) + ["", "## Frequently asked questions", ""]
    for q, a in _faq_pairs(d, cover=False): out += [f"### {q}", "", a, ""]
    return NL.join(out[:-1])

TRANSFORMS = {"baseline": baseline, "entity_structure_geo": entity_structure_geo, "faq_geo": faq_geo, "full_geo": full_geo}
