import ssl, requests
from requests.adapters import HTTPAdapter
class _Adapter(HTTPAdapter):
    def init_poolmanager(self, *a, **k):
        ctx = ssl.create_default_context()
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT   # Python 3.13+ strict X.509 mode rejects the sandbox proxy CA
        k['ssl_context'] = ctx; return super().init_poolmanager(*a, **k)
    def proxy_manager_for(self, proxy, **k):
        ctx = ssl.create_default_context(); ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
        k['ssl_context'] = ctx; return super().proxy_manager_for(proxy, **k)
class _S(requests.Session):
    def __init__(self, timeout):
        super().__init__(); self.mount('https://', _Adapter()); self._t = timeout
    def post(self, url, **k):
        k.setdefault('timeout', self._t); return super().post(url, **k)
def client(timeout=180): return _S(timeout)
