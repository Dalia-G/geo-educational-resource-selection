"""Freeze Study 2 inputs before execution: SHA-256 of every execution input and of the prespecified analysis code."""
import hashlib, json, os, glob
from datetime import datetime, timezone
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rel = lambda p: os.path.relpath(p, ROOT).replace(os.sep, '/')
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
exe = [os.path.join(ROOT, x) for x in ('study2_config.json', 'system_prompt_study2.txt', 'source/main_study_query_set.csv',
       'schedule/study2_schedule.csv', 'schedule/study2_label_mappings.json', 'corpus/document_departments.csv',
       'corpus/corpus_manifest.json', 'scripts/run_study2.py', 'scripts/http_client.py')]
exe += sorted(glob.glob(os.path.join(ROOT, 'corpus', '*', 'DOC_*.md')))
ana = [os.path.join(ROOT, x) for x in ('scripts/analyze_study2.py', 'protocol_study2.md')]
os.makedirs(os.path.join(ROOT, 'freeze'), exist_ok=True)
m = {"freeze_utc": datetime.now(timezone.utc).isoformat(), "note": "Created before the first Study 2 request was sent.",
     "files": [{"path": rel(p), "sha256": sha(p)} for p in exe], "analysis_files": [{"path": rel(p), "sha256": sha(p)} for p in ana]}
json.dump(m, open(os.path.join(ROOT, 'freeze', 'frozen_manifest.json'), 'w'), indent=1)
print(m['freeze_utc'], len(m['files']), 'execution files,', len(m['analysis_files']), 'analysis files')
