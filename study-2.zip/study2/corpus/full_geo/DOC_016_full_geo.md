# Course: Physical Chemistry

Course number: 5.61
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Chemistry
Academic level: Undergraduate
Term: Fall 2017
Resource type: Open educational course page

Course description:
This course is an introduction to quantum mechanics for use by chemists. Topics include particles and waves, wave mechanics, semi-classical quantum mechanics, matrix mechanics, perturbation theory, molecular orbital theory, molecular structure, molecular spectroscopy, and photochemistry. Emphasis is on creating and building confidence in the use of intuitive pictures.

Covered topics:
- Physical Chemistry

## Frequently asked questions

### What course is this?

5.61 Physical Chemistry is an MIT OpenCourseWare course in Chemistry.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2017.

### What topics are included?

Physical Chemistry
