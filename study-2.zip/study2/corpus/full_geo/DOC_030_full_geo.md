# Course: Classical Mechanics II

Course number: 8.223
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: January IAP 2017
Resource type: Open educational course page

Course description:
This undergraduate course is a broad, theoretical treatment of classical mechanics, useful in its own right for treating complex dynamical problems, but essential to understanding the foundations of quantum mechanics and statistical physics.

Covered topics:
- Classical Mechanics

## Frequently asked questions

### What course is this?

8.223 Classical Mechanics II is an MIT OpenCourseWare course in Physics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in January IAP 2017.

### What topics are included?

Classical Mechanics
