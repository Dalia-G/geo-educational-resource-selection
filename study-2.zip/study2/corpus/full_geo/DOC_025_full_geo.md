# Course: Matrix Methods in Data Analysis, Signal Processing, and Machine Learning

Course number: 18.065
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Spring 2018
Resource type: Open educational course page

Course description:
Linear algebra concepts are key for understanding and creating machine learning algorithms, especially as applied to deep learning and neural networks. This course reviews linear algebra with applications to probability and statistics and optimization–and above all a full explanation of deep learning.

Covered topics:
- Applied Mathematics
- Computation
- Electrical Engineering
- Linear Algebra
- Signal Processing

## Frequently asked questions

### What course is this?

18.065 Matrix Methods in Data Analysis, Signal Processing, and Machine Learning is an MIT OpenCourseWare course in Mathematics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2018.

### What topics are included?

Applied Mathematics, Computation, Electrical Engineering, Linear Algebra, Signal Processing
