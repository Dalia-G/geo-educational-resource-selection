# Course: Design and Manufacturing I

Course number: 2.007
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Spring 2009
Resource type: Open educational course page

Course description:
This course is a first subject in engineering design. It exposes students to engineering design material, challenges students to think deeply, and provides skills useful in professional practice. A major element of the course is design of a robot to participate in a challenge that changes from year to year. In Spring 2009, the theme was cleaning up the planet.

The course’s final project competition began in 1970 and has grown into an engineering design competition.

Covered topics:
- Robotics and Control Systems
- Mechanical Design

## Frequently asked questions

### What course is this?

2.007 Design and Manufacturing I is an MIT OpenCourseWare course in Mechanical Engineering.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2009.

### What topics are included?

Robotics and Control Systems, Mechanical Design
