# Course: Introduction to Computational Thinking and Data Science

Course number: 6.0002
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science
Academic level: Undergraduate
Term: Fall 2016
Resource type: Open educational course page

Course description:
6.0002 is the continuation of 6.0001 Introduction to Computer Science and Programming in Python and is intended for students with little or no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems and to help students, regardless of their major, feel justifiably confident of their ability to write small programs that allow them to accomplish useful goals. The class uses the Python 3.5 programming language.

Covered topics:
- Probability and Statistics

## Frequently asked questions

### What course is this?

6.0002 Introduction to Computational Thinking and Data Science is an MIT OpenCourseWare course in Electrical Engineering and Computer Science.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2016.

### What topics are included?

Probability and Statistics
