# Course: Introduction to Heat Transfer

Course number: 2.051
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Fall 2015
Resource type: Open educational course page

Course description:
This course is an introduction to the principal concepts and methods of heat transfer. The objectives of this integrated subject are to develop the fundamental principles and laws of heat transfer and to explore the implications of these principles for system behavior; to formulate the models necessary to study, analyze and design heat transfer systems through the application of these principles; and to develop the problem-solving skills essential to good engineering practice of heat transfer in real-world applications.

Covered topics:
- Thermodynamics

## Frequently asked questions

### What course is this?

2.051 Introduction to Heat Transfer is an MIT OpenCourseWare course in Mechanical Engineering.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2015.

### What topics are included?

Thermodynamics
