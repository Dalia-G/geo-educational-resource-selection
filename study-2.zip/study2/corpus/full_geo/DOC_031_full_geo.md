# Course: Classical Mechanics III

Course number: 8.09
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: Fall 2014
Resource type: Open educational course page

Course description:
This course covers Lagrangian and Hamiltonian mechanics, systems with constraints, rigid body dynamics, vibrations, central forces, Hamilton-Jacobi theory, action-angle variables, perturbation theory, and continuous systems. It provides an introduction to ideal and viscous fluid mechanics, including turbulence, as well as an introduction to nonlinear dynamics, including chaos.

Covered topics:
- Classical Mechanics

## Frequently asked questions

### What course is this?

8.09 Classical Mechanics III is an MIT OpenCourseWare course in Physics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2014.

### What topics are included?

Classical Mechanics
