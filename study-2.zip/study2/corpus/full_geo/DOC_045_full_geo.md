# Course: Introduction to Robotics

Course number: 2.12
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Fall 2005
Resource type: Open educational course page

Course description:
This course provides an overview of robot mechanisms, dynamics, and intelligent controls. Topics include planar and spatial kinematics, and motion planning; mechanism design for manipulators and mobile robots, multi-rigid-body dynamics, 3D graphic simulation; control design, actuators, and sensors; wireless networking, task modeling, human-machine interface, and embedded software. Weekly laboratories provide experience with servo drives, real-time control, and embedded software. Students will design and fabricate working robotic systems in a group-based term project.

Covered topics:
- Classical Mechanics
- Dynamics and Control
- Electrical Engineering
- Mechanical Design
- Mechanical Engineering
- Robotics and Control Systems

## Frequently asked questions

### What course is this?

2.12 Introduction to Robotics is an MIT OpenCourseWare course in Mechanical Engineering.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2005.

### What topics are included?

Classical Mechanics, Dynamics and Control, Electrical Engineering, Mechanical Design, Mechanical Engineering, Robotics and Control Systems
