# Course: Organic Chemistry I

Course number: 5.12
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Chemistry
Academic level: Undergraduate
Term: Spring 2003
Resource type: Open educational course page

Course description:
5.12 is an introduction to organic chemistry, focusing primarily on the basic principles to understand the structure and reactivity of organic molecules. Emphasis is on substitution and elimination reactions and chemistry of the carbonyl group. The course also provides an introduction to the chemistry of aromatic compounds.

Covered topics:
- Organic Chemistry

## Frequently asked questions

### What course is this?

5.12 Organic Chemistry I is an MIT OpenCourseWare course in Chemistry.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2003.

### What topics are included?

Organic Chemistry
