# Course: Organic Chemistry II

Course number: 5.13
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Chemistry
Academic level: Undergraduate
Term: Fall 2006
Resource type: Open educational course page

Course description:
This intermediate organic chemistry course focuses on the methods used to identify the structure of organic molecules, advanced principles of organic stereochemistry, organic reaction mechanisms, and methods used for the synthesis of organic compounds. Additional special topics include illustrating the role of organic chemistry in biology, medicine, and industry.

Covered topics:
- Organic Chemistry

## Frequently asked questions

### What course is this?

5.13 Organic Chemistry II is an MIT OpenCourseWare course in Chemistry.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2006.

### What topics are included?

Organic Chemistry
