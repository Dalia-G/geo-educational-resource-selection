# Course: Physics II: Electricity and Magnetism

Course number: 8.02
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: Spring 2007
Resource type: Open educational course page

Course description:
This freshman-level course is the second semester of introductory physics. The focus is on electricity and magnetism. The subject is taught using the TEAL, or Technology Enabled Active Learning, format, which uses small-group interaction and current technology. The TEAL/Studio Project is an approach to physics education designed to help students develop stronger intuition about and conceptual models of physical phenomena.

Covered topics:
- Electromagnetism

## Frequently asked questions

### What course is this?

8.02 Physics II: Electricity and Magnetism is an MIT OpenCourseWare course in Physics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2007.

### What topics are included?

Electromagnetism
