# Course: Design and Manufacturing II

Course number: 2.008
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Spring 2025
Resource type: Open educational course page

Course description:
This course introduces you to modern manufacturing with four areas of emphasis: manufacturing processes, equipment/control, systems, and design for manufacturing. The course exposes you to integration of engineering disciplines for determining manufacturing rate, cost, quality, and flexibility. Topics include process physics, equipment design and control, quality, design for manufacturing, and systems design and operation. Labs are integral parts of the course, and expose you to various manufacturing fundamentals and practices.

Covered topics:
- Materials Science and Engineering
- Mechanical Design
- Mechanical Engineering
- Operations Management
- Systems Design
- Systems Engineering

## Frequently asked questions

### What course is this?

2.008 Design and Manufacturing II is an MIT OpenCourseWare course in Mechanical Engineering.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2025.

### What topics are included?

Materials Science and Engineering, Mechanical Design, Mechanical Engineering, Operations Management, Systems Design, Systems Engineering
