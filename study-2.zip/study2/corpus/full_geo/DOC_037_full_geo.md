# Course: General Biochemistry

Course number: 7.05
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology
Academic level: Undergraduate
Term: Spring 2020
Resource type: Open educational course page

Course description:
This course focuses on contributions of biochemistry toward an understanding of the structure and functioning of organisms, tissues, and cells. Topics include:

Chemistry and functions of constituents of cells and tissues and the chemical and physical-chemical basis for the structures of nucleic acids, proteins, and carbohydrates.
Basic enzymology and biochemical reaction mechanisms involved in macromolecular synthesis and degradation, signaling, transport, and movement.
General metabolism of carbohydrates, fats, and nitrogen-containing materials such as amino acids, proteins, and related compounds.

NOTE: The first half of this course, taught by Prof. Yaffe, is available on the MITx platform as 7.05x Biochemistry: Biomolecules, Methods, and Mechanisms. This OCW website provides content primarily from the second half with Prof. Vander Heiden, which focuses on metabolism.

Covered topics:
- Analytical Chemistry
- Biochemistry
- Organic Chemistry
- Physical Chemistry

## Frequently asked questions

### What course is this?

7.05 General Biochemistry is an MIT OpenCourseWare course in Biology.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2020.

### What topics are included?

Analytical Chemistry, Biochemistry, Organic Chemistry, Physical Chemistry
