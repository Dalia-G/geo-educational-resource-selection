# Course: Introductory Biology

Course number: 7.013
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology
Academic level: Undergraduate
Term: Spring 2018
Resource type: Open educational course page

Course description:
The MIT Biology Department core Introductory Biology courses, 7.012, 7.013, 7.014, 7.015, and 7.016 all cover the same core material, which includes the fundamental principles of biochemistry, genetics, molecular biology, and cell biology. The focus of 7.013 is on genomic approaches to human biology, including neuroscience, development, immunology, tissue repair and stem cells, tissue engineering, and infectious and inherited diseases, including cancer.

Covered topics:
- Biochemistry
- Cell Biology
- Developmental Biology
- Genetics
- Molecular Biology

## Frequently asked questions

### What course is this?

7.013 Introductory Biology is an MIT OpenCourseWare course in Biology.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2018.

### What topics are included?

Biochemistry, Cell Biology, Developmental Biology, Genetics, Molecular Biology
