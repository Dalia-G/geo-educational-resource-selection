# Course: Linear Algebra

Course number: 18.06
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Spring 2010
Resource type: Open educational course page

Course description:
This is a basic subject on matrix theory and linear algebra. Emphasis is given to topics that will be useful in other disciplines, including systems of equations, vector spaces, determinants, eigenvalues, similarity, and positive definite matrices.

Covered topics:
- Linear Algebra

## Frequently asked questions

### What course is this?

18.06 Linear Algebra is an MIT OpenCourseWare course in Mathematics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2010.

### What topics are included?

Linear Algebra
