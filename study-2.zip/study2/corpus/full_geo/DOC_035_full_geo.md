# Course: Introductory Biology

Course number: 7.016
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology
Academic level: Undergraduate
Term: Fall 2018
Resource type: Open educational course page

Course description:
7.016 Introductory Biology provides an introduction to fundamental principles of biochemistry, molecular biology, and genetics for understanding the functions of living systems. Taught for the first time in Fall 2013, this course covers examples of the use of chemical biology and twenty-first-century molecular genetics in understanding human health and therapeutic intervention.

The MIT Biology Department Introductory Biology courses 7.012, 7.013, 7.014, 7.015, and 7.016 all cover the same core material, which includes the fundamental principles of biochemistry, genetics, molecular biology, and cell biology. Biological function at the molecular level is particularly emphasized and covers the structure and regulation of genes, as well as the structure and synthesis of proteins, how these molecules are integrated into cells, and how these cells are integrated into multicellular systems and organisms. In addition, each version of the subject has its own distinctive material.

Covered topics:
- Biochemistry
- Cancer
- Cell Biology
- Functional Genomics
- Genetics
- Microbiology
- Molecular Biology
- Virology

## Frequently asked questions

### What course is this?

7.016 Introductory Biology is an MIT OpenCourseWare course in Biology.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2018.

### What topics are included?

Biochemistry, Cancer, Cell Biology, Functional Genomics, Genetics, Microbiology, Molecular Biology, Virology
