# Course: Physics III: Vibrations and Waves

Course number: 8.03SC
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: Fall 2016
Resource type: Open educational course page

Course description:
Vibrations and waves are everywhere. If a system is disturbed from a stable equilibrium, the resultant motion will be waves and vibrations. A guitar string vibrates when plucked, producing sound waves, while reflected electromagnetic waves allow the string to be seen.

This course provides concepts and mathematical tools necessary to understand and explain a broad range of vibrations and waves. It explains that waves arise from many interconnected, coupled objects vibrating together. Topics include mechanical vibrations and waves, sound waves, electromagnetic waves, optics, and gravitational waves.

Covered topics:
- Atomic, Molecular, Optical Physics
- Classical Mechanics
- Electromagnetism

## Frequently asked questions

### What course is this?

8.03SC Physics III: Vibrations and Waves is an MIT OpenCourseWare course in Physics.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2016.

### What topics are included?

Atomic, Molecular, Optical Physics, Classical Mechanics, Electromagnetism
