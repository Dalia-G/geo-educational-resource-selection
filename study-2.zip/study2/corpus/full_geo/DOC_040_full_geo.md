# Course: Introduction to Solid-State Chemistry

Course number: 3.091
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Materials Science and Engineering
Academic level: Undergraduate
Term: Fall 2018
Resource type: Open educational course page

Course description:
In this course, we will explore what makes things in the world the way they are and why, to understand the science and consider the engineering. We learn not only why the physical world behaves the way it does, but also how to think with chemical intuition, which can’t be gained simply by observing the macroscopic world.

This 2018 version of 3.091 by Jeffrey Grossman and the 2010 OCW version by Don Sadoway cover similar topics and both provide complete learning materials. This 2018 version also includes Jeffrey Grossman’s innovative Goodie Bags, Why This Matters, and CHEMATLAS content, as well as additional practice problems, quizzes, and exams.

Covered topics:
- Chemical Engineering
- Materials Science and Engineering

## Frequently asked questions

### What course is this?

3.091 Introduction to Solid-State Chemistry is an MIT OpenCourseWare course in Materials Science and Engineering.

### What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2018.

### What topics are included?

Chemical Engineering, Materials Science and Engineering
