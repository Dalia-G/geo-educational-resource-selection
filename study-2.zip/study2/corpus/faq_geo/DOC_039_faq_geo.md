# 5.112: Principles of Chemical Science

## What course is this?

5.112 Principles of Chemical Science is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2005.

## What does the course cover?

5.112 is an introductory chemistry course for students with an unusually strong background in chemistry. Knowledge of calculus equivalent to MIT course 18.01 is recommended. Emphasis is on basic principles of atomic and molecular electronic structure, thermodynamics, acid-base and redox equilibria, chemical kinetics, and catalysis. The course also covers applications of basic principles to problems in metal coordination chemistry, organic chemistry, and biological chemistry.

## What topics are included?

Chemistry
