# 7.03: Genetics

## What course is this?

7.03 Genetics is an MIT OpenCourseWare course in Biology.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2004.

## What does the course cover?

This course discusses the principles of genetics with application to the study of biological function at the level of molecules, cells, and multicellular organisms, including humans. The topics include structure and function of genes, chromosomes and genomes, biological variation resulting from recombination, mutation, and selection, population genetics, use of genetic methods to analyze protein function, gene regulation, and inherited disease.

## What topics are included?

Cell Biology, Genetics, Molecular Biology
