# 8.07: Electromagnetism II

## What course is this?

8.07 Electromagnetism II is an MIT OpenCourseWare course in Physics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2012.

## What does the course cover?

This course is the second in a series on Electromagnetism beginning with Electromagnetism I (8.02 or 8.022). It is a survey of basic electromagnetic phenomena: electrostatics; magnetostatics; electromagnetic properties of matter; time-dependent electromagnetic fields; Maxwell’s equations; electromagnetic waves; emission, absorption, and scattering of radiation; and relativistic electrodynamics and mechanics.

## What topics are included?

Electromagnetism
