# 5.61: Physical Chemistry

## What course is this?

5.61 Physical Chemistry is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2017.

## What does the course cover?

This course is an introduction to quantum mechanics for use by chemists. Topics include particles and waves, wave mechanics, semi-classical quantum mechanics, matrix mechanics, perturbation theory, molecular orbital theory, molecular structure, molecular spectroscopy, and photochemistry. Emphasis is on creating and building confidence in the use of intuitive pictures.

## What topics are included?

Physical Chemistry
