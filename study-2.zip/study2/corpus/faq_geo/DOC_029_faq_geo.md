# 8.012: Physics I: Classical Mechanics

## What course is this?

8.012 Physics I: Classical Mechanics is an MIT OpenCourseWare course in Physics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2008.

## What does the course cover?

This class is an introduction to classical mechanics for students who are comfortable with calculus. The main topics are: Vectors, Kinematics, Forces, Motion, Momentum, Energy, Angular Motion, Angular Momentum, Gravity, Planetary Motion, Moving Frames, and the Motion of Rigid Bodies.

## What topics are included?

Classical Mechanics
