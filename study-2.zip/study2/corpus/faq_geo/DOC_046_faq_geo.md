# 2.002: Mechanics and Materials II

## What course is this?

2.002 Mechanics and Materials II is an MIT OpenCourseWare course in Mechanical Engineering.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2004.

## What does the course cover?

This course provides Mechanical Engineering students with an awareness of various responses exhibited by solid engineering materials when subjected to mechanical and thermal loadings; an introduction to the physical mechanisms associated with design-limiting behavior of engineering materials, especially stiffness, strength, toughness, and durability; an understanding of basic mechanical properties of engineering materials, testing procedures used to quantify these properties, and ways in which these properties characterize material response; quantitative skills to deal with materials-limiting problems in engineering design; and a basis for materials selection in mechanical design.

## What topics are included?

Materials Science and Engineering, Mechanical Engineering, Solid Mechanics
