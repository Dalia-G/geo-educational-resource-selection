# 9.01: Introduction to Neuroscience

## What course is this?

9.01 Introduction to Neuroscience is an MIT OpenCourseWare course in Brain and Cognitive Sciences.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2007.

## What does the course cover?

This course is an introduction to the mammalian nervous system, with emphasis on the structure and function of the human brain. Topics include the function of nerve cells, sensory systems, control of movement, learning and memory, and diseases of the brain.

## What topics are included?

Neuroscience
