# 18.05: Introduction to Probability and Statistics

## What course is this?

18.05 Introduction to Probability and Statistics is an MIT OpenCourseWare course in Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2022.

## What does the course cover?

This course provides an elementary introduction to probability and statistics with applications. Topics include basic combinatorics, random variables, probability distributions, Bayesian inference, hypothesis testing, confidence intervals, and linear regression.

## What topics are included?

Discrete Mathematics
