# 18.065: Matrix Methods in Data Analysis, Signal Processing, and Machine Learning

## What course is this?

18.065 Matrix Methods in Data Analysis, Signal Processing, and Machine Learning is an MIT OpenCourseWare course in Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2018.

## What does the course cover?

Linear algebra concepts are key for understanding and creating machine learning algorithms, especially as applied to deep learning and neural networks. This course reviews linear algebra with applications to probability and statistics and optimization–and above all a full explanation of deep learning.

## What topics are included?

Applied Mathematics, Computation, Electrical Engineering, Linear Algebra, Signal Processing
