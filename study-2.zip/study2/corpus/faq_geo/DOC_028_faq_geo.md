# 18.310: Principles of Discrete Applied Mathematics

## What course is this?

18.310 Principles of Discrete Applied Mathematics is an MIT OpenCourseWare course in Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2013.

## What does the course cover?

This course is an introduction to discrete applied mathematics. Topics include probability, counting, linear programming, number-theoretic algorithms, sorting, data compression, and error-correcting codes. This is a Communication Intensive in the Major (CI-M) course, and thus includes a writing component.

## What topics are included?

Applied Mathematics, Communication, Discrete Mathematics, Probability and Statistics
