# 5.62: Physical Chemistry II

## What course is this?

5.62 Physical Chemistry II is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2008.

## What does the course cover?

This course covers elementary statistical mechanics, transport properties, kinetic theory, solid state, reaction rate theory, and chemical reaction dynamics.

Acknowledgements
The staff for this course would like to acknowledge that these course materials include contributions from past instructors, textbooks, and other members of the MIT Chemistry Department affiliated with course #5.62. Since the following works have evolved over a period of many years, no single source can be attributed.

## What topics are included?

Chemical Engineering, Classical Mechanics, Physical Chemistry, Transport Processes
