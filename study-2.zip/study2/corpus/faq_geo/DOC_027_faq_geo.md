# 18.650: Statistics for Applications

## What course is this?

18.650 Statistics for Applications is an MIT OpenCourseWare course in Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2016.

## What does the course cover?

This course offers an in-depth the theoretical foundations for statistical methods that are useful in many applications. The goal is to understand the role of mathematics in the research and development of efficient statistical methods.

## What topics are included?

Probability and Statistics
