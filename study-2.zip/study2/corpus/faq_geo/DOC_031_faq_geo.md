# 8.09: Classical Mechanics III

## What course is this?

8.09 Classical Mechanics III is an MIT OpenCourseWare course in Physics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2014.

## What does the course cover?

This course covers Lagrangian and Hamiltonian mechanics, systems with constraints, rigid body dynamics, vibrations, central forces, Hamilton-Jacobi theory, action-angle variables, perturbation theory, and continuous systems. It provides an introduction to ideal and viscous fluid mechanics, including turbulence, as well as an introduction to nonlinear dynamics, including chaos.

## What topics are included?

Classical Mechanics
