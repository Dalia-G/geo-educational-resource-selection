# 2.001: Mechanics & Materials I

## What course is this?

2.001 Mechanics & Materials I is an MIT OpenCourseWare course in Mechanical Engineering.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2006.

## What does the course cover?

This course provides an introduction to the mechanics of solids with applications to science and engineering. It emphasizes three essential features of mechanics analyses: the geometry of motion and/or deformation of structures and conditions of geometric fit; the forces on and within structures and assemblages; and physical aspects of structural systems, including material properties, that quantify relations between forces and motions or deformation.

## What topics are included?

Materials Science and Engineering, Mechanical Engineering, Solid Mechanics
