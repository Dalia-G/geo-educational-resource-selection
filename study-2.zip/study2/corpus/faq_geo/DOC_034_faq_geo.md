# 7.013: Introductory Biology

## What course is this?

7.013 Introductory Biology is an MIT OpenCourseWare course in Biology.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2018.

## What does the course cover?

The MIT Biology Department core Introductory Biology courses, 7.012, 7.013, 7.014, 7.015, and 7.016 all cover the same core material, which includes the fundamental principles of biochemistry, genetics, molecular biology, and cell biology. The focus of 7.013 is on genomic approaches to human biology, including neuroscience, development, immunology, tissue repair and stem cells, tissue engineering, and infectious and inherited diseases, including cancer.

## What topics are included?

Biochemistry, Cell Biology, Developmental Biology, Genetics, Molecular Biology
