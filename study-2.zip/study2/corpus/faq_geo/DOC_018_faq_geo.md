# 2.051: Introduction to Heat Transfer

## What course is this?

2.051 Introduction to Heat Transfer is an MIT OpenCourseWare course in Mechanical Engineering.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2015.

## What does the course cover?

This course is an introduction to the principal concepts and methods of heat transfer. The objectives of this integrated subject are to develop the fundamental principles and laws of heat transfer and to explore the implications of these principles for system behavior; to formulate the models necessary to study, analyze and design heat transfer systems through the application of these principles; and to develop the problem-solving skills essential to good engineering practice of heat transfer in real-world applications.

## What topics are included?

Thermodynamics
