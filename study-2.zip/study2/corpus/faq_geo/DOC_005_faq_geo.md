# 5.111SC: Principles of Chemical Science

## What course is this?

5.111SC Principles of Chemical Science is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2014.

## What does the course cover?

This course provides an introduction to the chemistry of biological, inorganic, and organic molecules. The emphasis is on basic principles of atomic and molecular electronic structure, thermodynamics, acid-base and redox equilibria, chemical kinetics, and catalysis. One year of high school chemistry is the expected background for this freshman-level course.

The aims include developing a unified and intuitive view of how electronic structure controls the three-dimensional shape of molecules, the physical and chemical properties of molecules in gases, liquids and solids, and ultimately the assembly of macromolecules as in polymers and DNA. Relationships between chemistry and other fundamental sciences such as biology and physics are emphasized, as are the relationships between the science of chemistry to its applications in environmental science, atmospheric chemistry and electronic devices.

## What topics are included?

Atomic and molecular electronic structure, Thermodynamics, Acid-base equilibria, Redox equilibria, Chemical kinetics, Catalysis, Biological, inorganic, and organic molecules
