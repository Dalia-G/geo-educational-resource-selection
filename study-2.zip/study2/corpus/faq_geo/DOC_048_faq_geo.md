# 2.06: Fluid Dynamics

## What course is this?

2.06 Fluid Dynamics is an MIT OpenCourseWare course in Mechanical Engineering.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2013.

## What does the course cover?

This class provides students with an introduction to principal concepts and methods of fluid mechanics. Topics covered in the course include pressure, hydrostatics, and buoyancy; open systems and control volume analysis; mass conservation and momentum conservation for moving fluids; viscous fluid flows, flow through pipes; dimensional analysis; boundary layers, and lift and drag on objects. Students will work to formulate the models necessary to study, analyze, and design fluid systems through the application of these concepts, and to develop the problem-solving skills essential to good engineering practice of fluid mechanics in practical applications.

## What topics are included?

Fluid Mechanics, Hydrodynamics, Mechanical Engineering, Ocean Engineering
