# 5.13: Organic Chemistry II

## What course is this?

5.13 Organic Chemistry II is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2006.

## What does the course cover?

This intermediate organic chemistry course focuses on the methods used to identify the structure of organic molecules, advanced principles of organic stereochemistry, organic reaction mechanisms, and methods used for the synthesis of organic compounds. Additional special topics include illustrating the role of organic chemistry in biology, medicine, and industry.

## What topics are included?

Organic Chemistry
