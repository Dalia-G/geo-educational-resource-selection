# 18.600: Probability and Random Variables

## What course is this?

18.600 Probability and Random Variables is an MIT OpenCourseWare course in Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2019.

## What does the course cover?

This course introduces students to probability and random variables. Topics include distribution functions, binomial, geometric, hypergeometric, and Poisson distributions. The other topics covered are uniform, exponential, normal, gamma and beta distributions; conditional probability; Bayes theorem; joint distributions; Chebyshev inequality; law of large numbers; and central limit theorem.

## What topics are included?

Discrete Mathematics, Probability and Statistics
