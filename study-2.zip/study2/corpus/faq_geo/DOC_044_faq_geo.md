# 2.008: Design and Manufacturing II

## What course is this?

2.008 Design and Manufacturing II is an MIT OpenCourseWare course in Mechanical Engineering.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2025.

## What does the course cover?

This course introduces you to modern manufacturing with four areas of emphasis: manufacturing processes, equipment/control, systems, and design for manufacturing. The course exposes you to integration of engineering disciplines for determining manufacturing rate, cost, quality, and flexibility. Topics include process physics, equipment design and control, quality, design for manufacturing, and systems design and operation. Labs are integral parts of the course, and expose you to various manufacturing fundamentals and practices.

## What topics are included?

Materials Science and Engineering, Mechanical Design, Mechanical Engineering, Operations Management, Systems Design, Systems Engineering
