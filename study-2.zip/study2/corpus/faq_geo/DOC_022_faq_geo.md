# 6.1200J: Mathematics for Computer Science

## What course is this?

6.1200J Mathematics for Computer Science is an MIT OpenCourseWare course in Electrical Engineering and Computer Science; Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2024.

## What does the course cover?

This course covers elementary discrete mathematics for science and engineering, with a focus on mathematical tools and proof techniques useful in computer science. Topics include logical notation, sets, relations, elementary graph theory, state machines and invariants, induction and proofs by contradiction, recurrences, asymptotic notation, elementary analysis of algorithms, elementary number theory and cryptography, permutations and combinations, counting tools, and discrete probability.

## What topics are included?

Algorithms and Data Structures, Computation
