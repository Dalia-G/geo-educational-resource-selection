# 6.046J: Design and Analysis of Algorithms

## What course is this?

6.046J Design and Analysis of Algorithms is an MIT OpenCourseWare course in Electrical Engineering and Computer Science; Mathematics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2015.

## What does the course cover?

This is an intermediate algorithms course with an emphasis on teaching techniques for the design and analysis of efficient algorithms, emphasizing methods of application. Topics include divide-and-conquer, randomization, dynamic programming, greedy algorithms, incremental improvement, complexity, and cryptography.

## What topics are included?

Algorithms and Data Structures, Applied Mathematics, Computer Networks, Cryptography
