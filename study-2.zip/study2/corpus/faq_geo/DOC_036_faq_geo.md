# 7.15: Experimental Molecular Genetics

## What course is this?

7.15 Experimental Molecular Genetics is an MIT OpenCourseWare course in Biology.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2015.

## What does the course cover?

This project-based laboratory course provides students with in-depth experience in experimental molecular genetics, using modern methods of molecular biology and genetics to conduct original research. The course is geared towards students (including sophomores) who have a strong interest in a future career in biomedical research. This semester will focus on chemical genetics using Caenorhabditis elegans as a model system. Students will gain experience in research rationale and methods, as well as training in the planning, execution, and communication of experimental biology.

WARNING NOTICE

The experiments described in these materials are potentially hazardous and require a high level of safety training, special facilities and equipment, and supervision by appropriate individuals. You bear the sole responsibility, liability, and risk for the implementation of such safety procedures and measures. MIT shall have no responsibility, liability, or risk for the content or implementation of any of the material presented.

Legal Notice

## What topics are included?

Academic Writing, Biochemistry, Cell Biology, Genetics, Literature, Molecular Biology
