# 5.12: Organic Chemistry I

## What course is this?

5.12 Organic Chemistry I is an MIT OpenCourseWare course in Chemistry.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2003.

## What does the course cover?

5.12 is an introduction to organic chemistry, focusing primarily on the basic principles to understand the structure and reactivity of organic molecules. Emphasis is on substitution and elimination reactions and chemistry of the carbonyl group. The course also provides an introduction to the chemistry of aromatic compounds.

## What topics are included?

Organic Chemistry
