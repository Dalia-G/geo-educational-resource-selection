# 8.022: Physics II: Electricity and Magnetism

## What course is this?

8.022 Physics II: Electricity and Magnetism is an MIT OpenCourseWare course in Physics.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2004.

## What does the course cover?

Course 8.022 is one of several second-term freshman physics courses offered at MIT. It is geared towards students who are looking for a thorough and challenging introduction to electricity and magnetism. Topics covered include: Electric and magnetic field and potential; introduction to special relativity; Maxwell’s equations, in both differential and integral form; and properties of dielectrics and magnetic materials. In addition to the theoretical subject matter, several experiments in electricity and magnetism are performed by the students in the laboratory.

Acknowledgments

Prof. Sciolla would like to acknowledge the contributions of MIT Professors Scott Hughes and Peter Fisher to the development of this course. She would also like to acknowledge that these course materials include contributions from past instructors, textbooks, and other members of the MIT Physics Department affiliated with course 8.022. Since the following works have evolved over a period of many years, no single source can be attributed.

## What topics are included?

Electromagnetism
