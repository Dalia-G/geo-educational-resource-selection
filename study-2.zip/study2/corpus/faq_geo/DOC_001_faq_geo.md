# 6.0001: Introduction to Computer Science and Programming in Python

## What course is this?

6.0001 Introduction to Computer Science and Programming in Python is an MIT OpenCourseWare course in Electrical Engineering and Computer Science.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2016.

## What does the course cover?

6.0001 Introduction to Computer Science and Programming in Python is intended for students with little or no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems and to help students, regardless of their major, feel justifiably confident of their ability to write small programs that allow them to accomplish useful goals. The class uses the Python 3.5 programming language.

## What topics are included?

Algorithms and Data Structures, Programming Languages
