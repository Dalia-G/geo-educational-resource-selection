# 6.006: Introduction to Algorithms

## What course is this?

6.006 Introduction to Algorithms is an MIT OpenCourseWare course in Electrical Engineering and Computer Science.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Spring 2020.

## What does the course cover?

This course is an introduction to mathematical modeling of computational problems, as well as common algorithms, algorithmic paradigms, and data structures used to solve these problems. It emphasizes the relationship between algorithms and programming and introduces basic performance measures and analysis techniques for these problems.

## What topics are included?

Algorithms and Data Structures, Theory of Computation
