# 6.830: Database Systems

## What course is this?

6.830 Database Systems is an MIT OpenCourseWare course in Electrical Engineering and Computer Science.

## What academic level is the course?

The course is listed as Graduate; Undergraduate and was taught in Fall 2010.

## What does the course cover?

This course relies on primary readings from the database community to introduce graduate students to the foundations of database systems, focusing on basics such as the relational algebra and data model, schema normalization, query optimization, and transactions. It is designed for students who have taken 6.033 or equivalent; no prior database experience is assumed, though students who have taken an undergraduate course in databases are encouraged to attend.

## What topics are included?

Algorithms and Data Structures, Data Mining, Software Design and Engineering
