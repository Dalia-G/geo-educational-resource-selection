# 6.100L: Introduction to CS and Programming using Python

## What course is this?

6.100L Introduction to CS and Programming using Python is an MIT OpenCourseWare course in Electrical Engineering and Computer Science.

## What academic level is the course?

The course is listed as Undergraduate and was taught in Fall 2022.

## What does the course cover?

This subject is aimed at students with little to no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems. It also aims to help students, regardless of their major, feel justifiably confident in their ability to write simple programs that allow them to accomplish useful goals. The class will use the Python 3 programming language.

## What topics are included?

Programming Languages
