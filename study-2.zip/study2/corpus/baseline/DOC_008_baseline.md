# 6.830: Database Systems

Department: Electrical Engineering and Computer Science
Level: Graduate; Undergraduate
Term: Fall 2010

Description:
This course relies on primary readings from the database community to introduce graduate students to the foundations of database systems, focusing on basics such as the relational algebra and data model, schema normalization, query optimization, and transactions. It is designed for students who have taken 6.033 or equivalent; no prior database experience is assumed, though students who have taken an undergraduate course in databases are encouraged to attend.

Topics:
Algorithms and Data Structures, Data Mining, Software Design and Engineering
