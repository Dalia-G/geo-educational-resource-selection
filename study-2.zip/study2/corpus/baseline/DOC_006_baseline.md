# 2.007: Design and Manufacturing I

Department: Mechanical Engineering
Level: Undergraduate
Term: Spring 2009

Description:
This course is a first subject in engineering design. It exposes students to engineering design material, challenges students to think deeply, and provides skills useful in professional practice. A major element of the course is design of a robot to participate in a challenge that changes from year to year. In Spring 2009, the theme was cleaning up the planet.

The course’s final project competition began in 1970 and has grown into an engineering design competition.

Topics:
Robotics and Control Systems, Mechanical Design
