# 6.033: Computer System Engineering

Department: Electrical Engineering and Computer Science
Level: Undergraduate
Term: Spring 2018

Description:
This class covers topics on the engineering of computer software and hardware systems. Topics include techniques for controlling complexity; strong modularity using client-server design, operating systems; performance, networks; naming; security and privacy; fault-tolerant systems, atomicity and coordination of concurrent activities, and recovery; impact of computer systems on society.

Topics:
Computer Design and Engineering, Computer Networks, Operating Systems, Software Design and Engineering
