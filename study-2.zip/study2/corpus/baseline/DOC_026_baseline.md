# 18.600: Probability and Random Variables

Department: Mathematics
Level: Undergraduate
Term: Fall 2019

Description:
This course introduces students to probability and random variables. Topics include distribution functions, binomial, geometric, hypergeometric, and Poisson distributions. The other topics covered are uniform, exponential, normal, gamma and beta distributions; conditional probability; Bayes theorem; joint distributions; Chebyshev inequality; law of large numbers; and central limit theorem.

Topics:
Discrete Mathematics, Probability and Statistics
