# 2.051: Introduction to Heat Transfer

Department: Mechanical Engineering
Level: Undergraduate
Term: Fall 2015

Description:
This course is an introduction to the principal concepts and methods of heat transfer. The objectives of this integrated subject are to develop the fundamental principles and laws of heat transfer and to explore the implications of these principles for system behavior; to formulate the models necessary to study, analyze and design heat transfer systems through the application of these principles; and to develop the problem-solving skills essential to good engineering practice of heat transfer in real-world applications.

Topics:
Thermodynamics
