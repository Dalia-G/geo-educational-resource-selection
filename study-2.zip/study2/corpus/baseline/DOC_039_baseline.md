# 5.112: Principles of Chemical Science

Department: Chemistry
Level: Undergraduate
Term: Fall 2005

Description:
5.112 is an introductory chemistry course for students with an unusually strong background in chemistry. Knowledge of calculus equivalent to MIT course 18.01 is recommended. Emphasis is on basic principles of atomic and molecular electronic structure, thermodynamics, acid-base and redox equilibria, chemical kinetics, and catalysis. The course also covers applications of basic principles to problems in metal coordination chemistry, organic chemistry, and biological chemistry.

Topics:
Chemistry
