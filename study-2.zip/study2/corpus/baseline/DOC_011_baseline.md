# 8.03SC: Physics III: Vibrations and Waves

Department: Physics
Level: Undergraduate
Term: Fall 2016

Description:
Vibrations and waves are everywhere. If a system is disturbed from a stable equilibrium, the resultant motion will be waves and vibrations. A guitar string vibrates when plucked, producing sound waves, while reflected electromagnetic waves allow the string to be seen.

This course provides concepts and mathematical tools necessary to understand and explain a broad range of vibrations and waves. It explains that waves arise from many interconnected, coupled objects vibrating together. Topics include mechanical vibrations and waves, sound waves, electromagnetic waves, optics, and gravitational waves.

Topics:
Atomic, Molecular, Optical Physics, Classical Mechanics, Electromagnetism
