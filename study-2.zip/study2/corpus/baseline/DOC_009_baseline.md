# 18.05: Introduction to Probability and Statistics

Department: Mathematics
Level: Undergraduate
Term: Spring 2022

Description:
This course provides an elementary introduction to probability and statistics with applications. Topics include basic combinatorics, random variables, probability distributions, Bayesian inference, hypothesis testing, confidence intervals, and linear regression.

Topics:
Discrete Mathematics
