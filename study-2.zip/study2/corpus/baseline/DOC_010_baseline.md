# 18.200: Principles of Discrete Applied Mathematics

Department: Mathematics
Level: Undergraduate
Term: Spring 2024

Description:
This course will teach illustrative topics in discrete applied mathematics, including counting, generating functions, probability, linear optimization, algebraic structures, basic number theory, information theory, and coding theory. It is a CI-M, or Communication Intensive in the Major, course and includes a writing component.

Topics:
Discrete Mathematics, Linear Programming, Probability Theory, Information Theory, Coding Theory
