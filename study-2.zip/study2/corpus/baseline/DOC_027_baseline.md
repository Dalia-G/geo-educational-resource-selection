# 18.650: Statistics for Applications

Department: Mathematics
Level: Undergraduate
Term: Fall 2016

Description:
This course offers an in-depth the theoretical foundations for statistical methods that are useful in many applications. The goal is to understand the role of mathematics in the research and development of efficient statistical methods.

Topics:
Probability and Statistics
