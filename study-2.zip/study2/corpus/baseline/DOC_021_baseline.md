# 6.046J: Design and Analysis of Algorithms

Department: Electrical Engineering and Computer Science; Mathematics
Level: Undergraduate
Term: Spring 2015

Description:
This is an intermediate algorithms course with an emphasis on teaching techniques for the design and analysis of efficient algorithms, emphasizing methods of application. Topics include divide-and-conquer, randomization, dynamic programming, greedy algorithms, incremental improvement, complexity, and cryptography.

Topics:
Algorithms and Data Structures, Applied Mathematics, Computer Networks, Cryptography
