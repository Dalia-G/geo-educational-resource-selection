# 18.310: Principles of Discrete Applied Mathematics

Department: Mathematics
Level: Undergraduate
Term: Fall 2013

Description:
This course is an introduction to discrete applied mathematics. Topics include probability, counting, linear programming, number-theoretic algorithms, sorting, data compression, and error-correcting codes. This is a Communication Intensive in the Major (CI-M) course, and thus includes a writing component.

Topics:
Applied Mathematics, Communication, Discrete Mathematics, Probability and Statistics
