# 8.223: Classical Mechanics II

Department: Physics
Level: Undergraduate
Term: January IAP 2017

Description:
This undergraduate course is a broad, theoretical treatment of classical mechanics, useful in its own right for treating complex dynamical problems, but essential to understanding the foundations of quantum mechanics and statistical physics.

Topics:
Classical Mechanics
