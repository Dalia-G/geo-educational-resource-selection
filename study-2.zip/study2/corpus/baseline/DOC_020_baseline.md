# 6.0002: Introduction to Computational Thinking and Data Science

Department: Electrical Engineering and Computer Science
Level: Undergraduate
Term: Fall 2016

Description:
6.0002 is the continuation of 6.0001 Introduction to Computer Science and Programming in Python and is intended for students with little or no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems and to help students, regardless of their major, feel justifiably confident of their ability to write small programs that allow them to accomplish useful goals. The class uses the Python 3.5 programming language.

Topics:
Probability and Statistics
