# 6.100L: Introduction to CS and Programming using Python

Department: Electrical Engineering and Computer Science
Level: Undergraduate
Term: Fall 2022

Description:
This subject is aimed at students with little to no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems. It also aims to help students, regardless of their major, feel justifiably confident in their ability to write simple programs that allow them to accomplish useful goals. The class will use the Python 3 programming language.

Topics:
Programming Languages
