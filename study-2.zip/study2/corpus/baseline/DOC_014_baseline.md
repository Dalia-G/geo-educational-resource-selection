# 7.29J: Cellular Neurobiology

Department: Biology; Brain and Cognitive Sciences
Level: Undergraduate
Term: Spring 2012

Description:
This course serves as an introduction to the structure and function of the nervous system. Emphasis is placed on the cellular properties of neurons and other excitable cells. Topics covered include the structure and biophysical properties of excitable cells, synaptic transmission, neurochemistry, neurodevelopment, and the integration of information in simple systems and the visual system.

Topics:
Neurobiology, Neuroscience, Cognitive Science
