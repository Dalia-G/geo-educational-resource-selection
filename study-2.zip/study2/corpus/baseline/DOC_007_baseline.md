# 6.006: Introduction to Algorithms

Department: Electrical Engineering and Computer Science
Level: Undergraduate
Term: Spring 2020

Description:
This course is an introduction to mathematical modeling of computational problems, as well as common algorithms, algorithmic paradigms, and data structures used to solve these problems. It emphasizes the relationship between algorithms and programming and introduces basic performance measures and analysis techniques for these problems.

Topics:
Algorithms and Data Structures, Theory of Computation
