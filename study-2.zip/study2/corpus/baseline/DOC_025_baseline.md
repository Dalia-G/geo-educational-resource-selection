# 18.065: Matrix Methods in Data Analysis, Signal Processing, and Machine Learning

Department: Mathematics
Level: Undergraduate
Term: Spring 2018

Description:
Linear algebra concepts are key for understanding and creating machine learning algorithms, especially as applied to deep learning and neural networks. This course reviews linear algebra with applications to probability and statistics and optimization–and above all a full explanation of deep learning.

Topics:
Applied Mathematics, Computation, Electrical Engineering, Linear Algebra, Signal Processing
