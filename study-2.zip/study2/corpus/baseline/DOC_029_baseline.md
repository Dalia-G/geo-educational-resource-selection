# 8.012: Physics I: Classical Mechanics

Department: Physics
Level: Undergraduate
Term: Fall 2008

Description:
This class is an introduction to classical mechanics for students who are comfortable with calculus. The main topics are: Vectors, Kinematics, Forces, Motion, Momentum, Energy, Angular Motion, Angular Momentum, Gravity, Planetary Motion, Moving Frames, and the Motion of Rigid Bodies.

Topics:
Classical Mechanics
