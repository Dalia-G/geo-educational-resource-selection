# 5.13: Organic Chemistry II

Department: Chemistry
Level: Undergraduate
Term: Fall 2006

Description:
This intermediate organic chemistry course focuses on the methods used to identify the structure of organic molecules, advanced principles of organic stereochemistry, organic reaction mechanisms, and methods used for the synthesis of organic compounds. Additional special topics include illustrating the role of organic chemistry in biology, medicine, and industry.

Topics:
Organic Chemistry
