# 5.61: Physical Chemistry

Department: Chemistry
Level: Undergraduate
Term: Fall 2017

Description:
This course is an introduction to quantum mechanics for use by chemists. Topics include particles and waves, wave mechanics, semi-classical quantum mechanics, matrix mechanics, perturbation theory, molecular orbital theory, molecular structure, molecular spectroscopy, and photochemistry. Emphasis is on creating and building confidence in the use of intuitive pictures.

Topics:
Physical Chemistry
