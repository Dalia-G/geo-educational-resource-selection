# 18.06: Linear Algebra

Department: Mathematics
Level: Undergraduate
Term: Spring 2010

Description:
This is a basic subject on matrix theory and linear algebra. Emphasis is given to topics that will be useful in other disciplines, including systems of equations, vector spaces, determinants, eigenvalues, similarity, and positive definite matrices.

Topics:
Linear Algebra
