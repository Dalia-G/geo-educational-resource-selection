# 6.1200J: Mathematics for Computer Science

Department: Electrical Engineering and Computer Science; Mathematics
Level: Undergraduate
Term: Spring 2024

Description:
This course covers elementary discrete mathematics for science and engineering, with a focus on mathematical tools and proof techniques useful in computer science. Topics include logical notation, sets, relations, elementary graph theory, state machines and invariants, induction and proofs by contradiction, recurrences, asymptotic notation, elementary analysis of algorithms, elementary number theory and cryptography, permutations and combinations, counting tools, and discrete probability.

Topics:
Algorithms and Data Structures, Computation
