# 5.12: Organic Chemistry I

Department: Chemistry
Level: Undergraduate
Term: Spring 2003

Description:
5.12 is an introduction to organic chemistry, focusing primarily on the basic principles to understand the structure and reactivity of organic molecules. Emphasis is on substitution and elimination reactions and chemistry of the carbonyl group. The course also provides an introduction to the chemistry of aromatic compounds.

Topics:
Organic Chemistry
