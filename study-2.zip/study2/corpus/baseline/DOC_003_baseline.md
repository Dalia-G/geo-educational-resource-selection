# 8.01SC: Classical Mechanics

Department: Physics
Level: Undergraduate
Term: Fall 2016

Description:
This first course in the physics curriculum introduces classical mechanics. Historically, a set of core concepts—space, time, mass, force, momentum, torque, and angular momentum—were introduced in classical mechanics in order to solve the most famous physics problem, the motion of the planets.

The principles of mechanics successfully described many other phenomena encountered in the world. Conservation laws involving energy, momentum and angular momentum provided a second parallel approach to solving many of the same problems. In this course, we will investigate both approaches: Force and conservation laws.

Our goal is to develop a conceptual understanding of the core concepts, a familiarity with the experimental verification of our theoretical laws, and an ability to apply the theoretical framework to describe and predict the motions of bodies.

Topics:
Classical Mechanics
