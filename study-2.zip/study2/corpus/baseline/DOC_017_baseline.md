# 2.001: Mechanics & Materials I

Department: Mechanical Engineering
Level: Undergraduate
Term: Fall 2006

Description:
This course provides an introduction to the mechanics of solids with applications to science and engineering. It emphasizes three essential features of mechanics analyses: the geometry of motion and/or deformation of structures and conditions of geometric fit; the forces on and within structures and assemblages; and physical aspects of structural systems, including material properties, that quantify relations between forces and motions or deformation.

Topics:
Materials Science and Engineering, Mechanical Engineering, Solid Mechanics
