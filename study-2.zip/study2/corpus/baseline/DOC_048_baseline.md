# 2.06: Fluid Dynamics

Department: Mechanical Engineering
Level: Undergraduate
Term: Spring 2013

Description:
This class provides students with an introduction to principal concepts and methods of fluid mechanics. Topics covered in the course include pressure, hydrostatics, and buoyancy; open systems and control volume analysis; mass conservation and momentum conservation for moving fluids; viscous fluid flows, flow through pipes; dimensional analysis; boundary layers, and lift and drag on objects. Students will work to formulate the models necessary to study, analyze, and design fluid systems through the application of these concepts, and to develop the problem-solving skills essential to good engineering practice of fluid mechanics in practical applications.

Topics:
Fluid Mechanics, Hydrodynamics, Mechanical Engineering, Ocean Engineering
