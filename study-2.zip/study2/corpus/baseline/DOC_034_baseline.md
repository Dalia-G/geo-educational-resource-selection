# 7.013: Introductory Biology

Department: Biology
Level: Undergraduate
Term: Spring 2018

Description:
The MIT Biology Department core Introductory Biology courses, 7.012, 7.013, 7.014, 7.015, and 7.016 all cover the same core material, which includes the fundamental principles of biochemistry, genetics, molecular biology, and cell biology. The focus of 7.013 is on genomic approaches to human biology, including neuroscience, development, immunology, tissue repair and stem cells, tissue engineering, and infectious and inherited diseases, including cancer.

Topics:
Biochemistry, Cell Biology, Developmental Biology, Genetics, Molecular Biology
