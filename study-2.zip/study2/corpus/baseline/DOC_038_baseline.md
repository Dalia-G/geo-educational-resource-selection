# 9.01: Introduction to Neuroscience

Department: Brain and Cognitive Sciences
Level: Undergraduate
Term: Fall 2007

Description:
This course is an introduction to the mammalian nervous system, with emphasis on the structure and function of the human brain. Topics include the function of nerve cells, sensory systems, control of movement, learning and memory, and diseases of the brain.

Topics:
Neuroscience
