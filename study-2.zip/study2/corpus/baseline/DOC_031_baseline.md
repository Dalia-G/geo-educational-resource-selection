# 8.09: Classical Mechanics III

Department: Physics
Level: Undergraduate
Term: Fall 2014

Description:
This course covers Lagrangian and Hamiltonian mechanics, systems with constraints, rigid body dynamics, vibrations, central forces, Hamilton-Jacobi theory, action-angle variables, perturbation theory, and continuous systems. It provides an introduction to ideal and viscous fluid mechanics, including turbulence, as well as an introduction to nonlinear dynamics, including chaos.

Topics:
Classical Mechanics
