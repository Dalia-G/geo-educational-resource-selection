# 7.03: Genetics

Department: Biology
Level: Undergraduate
Term: Fall 2004

Description:
This course discusses the principles of genetics with application to the study of biological function at the level of molecules, cells, and multicellular organisms, including humans. The topics include structure and function of genes, chromosomes and genomes, biological variation resulting from recombination, mutation, and selection, population genetics, use of genetic methods to analyze protein function, gene regulation, and inherited disease.

Topics:
Cell Biology, Genetics, Molecular Biology
