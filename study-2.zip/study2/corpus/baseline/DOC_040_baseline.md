# 3.091: Introduction to Solid-State Chemistry

Department: Materials Science and Engineering
Level: Undergraduate
Term: Fall 2018

Description:
In this course, we will explore what makes things in the world the way they are and why, to understand the science and consider the engineering. We learn not only why the physical world behaves the way it does, but also how to think with chemical intuition, which can’t be gained simply by observing the macroscopic world.

This 2018 version of 3.091 by Jeffrey Grossman and the 2010 OCW version by Don Sadoway cover similar topics and both provide complete learning materials. This 2018 version also includes Jeffrey Grossman’s innovative Goodie Bags, Why This Matters, and CHEMATLAS content, as well as additional practice problems, quizzes, and exams.

Topics:
Chemical Engineering, Materials Science and Engineering
