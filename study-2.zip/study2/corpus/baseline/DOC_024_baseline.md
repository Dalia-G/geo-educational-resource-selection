# 18.700: Linear Algebra

Department: Mathematics
Level: Undergraduate
Term: Fall 2013

Description:
This course offers a rigorous treatment of linear algebra, including vector spaces, systems of linear equations, bases, linear independence, matrices, determinants, eigenvalues, inner products, quadratic forms, and canonical forms of matrices. Compared with 18.06 Linear Algebra, more emphasis is placed on theory and proofs.

Topics:
Linear Algebra
