# Course: Genetics

Course number: 7.03
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology
Academic level: Undergraduate
Term: Fall 2004
Resource type: Open educational course page

Course description:
This course discusses the principles of genetics with application to the study of biological function at the level of molecules, cells, and multicellular organisms, including humans. The topics include structure and function of genes, chromosomes and genomes, biological variation resulting from recombination, mutation, and selection, population genetics, use of genetic methods to analyze protein function, gene regulation, and inherited disease.

Covered topics:
- Cell Biology
- Genetics
- Molecular Biology
