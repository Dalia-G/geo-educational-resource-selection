# Course: Mechanics & Materials I

Course number: 2.001
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Fall 2006
Resource type: Open educational course page

Course description:
This course provides an introduction to the mechanics of solids with applications to science and engineering. It emphasizes three essential features of mechanics analyses: the geometry of motion and/or deformation of structures and conditions of geometric fit; the forces on and within structures and assemblages; and physical aspects of structural systems, including material properties, that quantify relations between forces and motions or deformation.

Covered topics:
- Materials Science and Engineering
- Mechanical Engineering
- Solid Mechanics
