# Course: Thermodynamics & Kinetics

Course number: 5.60
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Chemistry
Academic level: Undergraduate
Term: Spring 2008
Resource type: Open educational course page

Course description:
This subject deals primarily with equilibrium properties of macroscopic systems, basic thermodynamics, chemical equilibrium of reactions in gas and solution phase, and rates of chemical reactions.

Acknowledgements
The material for 5.60 has evolved over a period of many years, and therefore several faculty members have contributed to the development of the course contents. The following are known to have assisted in preparing the lecture notes available on OpenCourseWare: Emeritus Professors of Chemistry: Robert A. Alberty, Carl W. Garland, Irwin Oppenheim, John S. Waugh. Professors of Chemistry: Moungi Bawendi, John M. Deutch, Robert W. Field, Robert G. Griffin, Keith A. Nelson, Robert J. Silbey, Jeffrey I. Steinfeld. Professor of Bioengineering and Computer Science: Bruce Tidor. Professor of Chemistry, Rice University: James L. Kinsey. Professor of Physics, University of Illinois: Philip W. Phillips.

Covered topics:
- Classical Mechanics
- Physical Chemistry
- Thermodynamics
