# Course: Computer System Engineering

Course number: 6.033
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science
Academic level: Undergraduate
Term: Spring 2018
Resource type: Open educational course page

Course description:
This class covers topics on the engineering of computer software and hardware systems. Topics include techniques for controlling complexity; strong modularity using client-server design, operating systems; performance, networks; naming; security and privacy; fault-tolerant systems, atomicity and coordination of concurrent activities, and recovery; impact of computer systems on society.

Covered topics:
- Computer Design and Engineering
- Computer Networks
- Operating Systems
- Software Design and Engineering
