# Course: Introduction to CS and Programming using Python

Course number: 6.100L
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science
Academic level: Undergraduate
Term: Fall 2022
Resource type: Open educational course page

Course description:
This subject is aimed at students with little to no programming experience. It aims to provide students with an understanding of the role computation can play in solving problems. It also aims to help students, regardless of their major, feel justifiably confident in their ability to write simple programs that allow them to accomplish useful goals. The class will use the Python 3 programming language.

Covered topics:
- Programming Languages
