# Course: Introduction to Algorithms

Course number: 6.006
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science
Academic level: Undergraduate
Term: Spring 2020
Resource type: Open educational course page

Course description:
This course is an introduction to mathematical modeling of computational problems, as well as common algorithms, algorithmic paradigms, and data structures used to solve these problems. It emphasizes the relationship between algorithms and programming and introduces basic performance measures and analysis techniques for these problems.

Covered topics:
- Algorithms and Data Structures
- Theory of Computation
