# Course: Physics II: Electricity and Magnetism

Course number: 8.022
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: Fall 2004
Resource type: Open educational course page

Course description:
Course 8.022 is one of several second-term freshman physics courses offered at MIT. It is geared towards students who are looking for a thorough and challenging introduction to electricity and magnetism. Topics covered include: Electric and magnetic field and potential; introduction to special relativity; Maxwell’s equations, in both differential and integral form; and properties of dielectrics and magnetic materials. In addition to the theoretical subject matter, several experiments in electricity and magnetism are performed by the students in the laboratory.

Acknowledgments

Prof. Sciolla would like to acknowledge the contributions of MIT Professors Scott Hughes and Peter Fisher to the development of this course. She would also like to acknowledge that these course materials include contributions from past instructors, textbooks, and other members of the MIT Physics Department affiliated with course 8.022. Since the following works have evolved over a period of many years, no single source can be attributed.

Covered topics:
- Electromagnetism
