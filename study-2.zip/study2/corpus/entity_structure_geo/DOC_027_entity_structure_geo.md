# Course: Statistics for Applications

Course number: 18.650
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Fall 2016
Resource type: Open educational course page

Course description:
This course offers an in-depth the theoretical foundations for statistical methods that are useful in many applications. The goal is to understand the role of mathematics in the research and development of efficient statistical methods.

Covered topics:
- Probability and Statistics
