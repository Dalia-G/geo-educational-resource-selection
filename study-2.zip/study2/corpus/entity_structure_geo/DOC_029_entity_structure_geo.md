# Course: Physics I: Classical Mechanics

Course number: 8.012
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Physics
Academic level: Undergraduate
Term: Fall 2008
Resource type: Open educational course page

Course description:
This class is an introduction to classical mechanics for students who are comfortable with calculus. The main topics are: Vectors, Kinematics, Forces, Motion, Momentum, Energy, Angular Motion, Angular Momentum, Gravity, Planetary Motion, Moving Frames, and the Motion of Rigid Bodies.

Covered topics:
- Classical Mechanics
