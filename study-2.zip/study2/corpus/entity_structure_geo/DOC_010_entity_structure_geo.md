# Course: Principles of Discrete Applied Mathematics

Course number: 18.200
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Spring 2024
Resource type: Open educational course page

Course description:
This course will teach illustrative topics in discrete applied mathematics, including counting, generating functions, probability, linear optimization, algebraic structures, basic number theory, information theory, and coding theory. It is a CI-M, or Communication Intensive in the Major, course and includes a writing component.

Covered topics:
- Discrete Mathematics
- Linear Programming
- Probability Theory
- Information Theory
- Coding Theory
