# Course: Mathematics for Computer Science

Course number: 6.1200J
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science; Mathematics
Academic level: Undergraduate
Term: Spring 2024
Resource type: Open educational course page

Course description:
This course covers elementary discrete mathematics for science and engineering, with a focus on mathematical tools and proof techniques useful in computer science. Topics include logical notation, sets, relations, elementary graph theory, state machines and invariants, induction and proofs by contradiction, recurrences, asymptotic notation, elementary analysis of algorithms, elementary number theory and cryptography, permutations and combinations, counting tools, and discrete probability.

Covered topics:
- Algorithms and Data Structures
- Computation
