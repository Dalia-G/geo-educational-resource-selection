# Course: Introduction to Probability and Statistics

Course number: 18.05
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Spring 2022
Resource type: Open educational course page

Course description:
This course provides an elementary introduction to probability and statistics with applications. Topics include basic combinatorics, random variables, probability distributions, Bayesian inference, hypothesis testing, confidence intervals, and linear regression.

Covered topics:
- Discrete Mathematics
