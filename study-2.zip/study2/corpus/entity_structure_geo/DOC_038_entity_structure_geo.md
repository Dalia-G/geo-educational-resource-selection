# Course: Introduction to Neuroscience

Course number: 9.01
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Brain and Cognitive Sciences
Academic level: Undergraduate
Term: Fall 2007
Resource type: Open educational course page

Course description:
This course is an introduction to the mammalian nervous system, with emphasis on the structure and function of the human brain. Topics include the function of nerve cells, sensory systems, control of movement, learning and memory, and diseases of the brain.

Covered topics:
- Neuroscience
