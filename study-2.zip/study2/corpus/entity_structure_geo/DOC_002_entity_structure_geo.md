# Course: Linear Algebra

Course number: 18.06
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Spring 2010
Resource type: Open educational course page

Course description:
This is a basic subject on matrix theory and linear algebra. Emphasis is given to topics that will be useful in other disciplines, including systems of equations, vector spaces, determinants, eigenvalues, similarity, and positive definite matrices.

Covered topics:
- Linear Algebra
