# Course: Elements of Mechanical Design

Course number: 2.72
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Spring 2009
Resource type: Open educational course page

Course description:
This is an advanced course on modeling, design, integration and best practices for use of machine elements such as bearings, springs, gears, cams and mechanisms. Modeling and analysis of these elements is based upon extensive application of physics, mathematics and core mechanical engineering principles (solid mechanics, fluid mechanics, manufacturing, estimation, computer simulation, etc.). These principles are reinforced via (1) hands-on laboratory experiences wherein students conduct experiments and disassemble machines and (2) a substantial design project wherein students model, design, fabricate and characterize a mechanical system that is relevant to a real world application. Students master the materials via problems sets that are directly related to, and coordinated with, the deliverables of their project. Student assessment is based upon mastery of the course materials and the student’s ability to synthesize, model and fabricate a mechanical device subject to engineering constraints (e.g. cost and time/schedule).

Covered topics:
- Mechanical Design
- Mechanical Engineering
- Project Management
