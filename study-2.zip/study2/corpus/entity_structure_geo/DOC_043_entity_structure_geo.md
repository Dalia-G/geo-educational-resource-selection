# Course: Physical Chemistry II

Course number: 5.62
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Chemistry
Academic level: Undergraduate
Term: Spring 2008
Resource type: Open educational course page

Course description:
This course covers elementary statistical mechanics, transport properties, kinetic theory, solid state, reaction rate theory, and chemical reaction dynamics.

Acknowledgements
The staff for this course would like to acknowledge that these course materials include contributions from past instructors, textbooks, and other members of the MIT Chemistry Department affiliated with course #5.62. Since the following works have evolved over a period of many years, no single source can be attributed.

Covered topics:
- Chemical Engineering
- Classical Mechanics
- Physical Chemistry
- Transport Processes
