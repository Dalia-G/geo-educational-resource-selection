# Course: Introduction to Biology

Course number: 7.012
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology
Academic level: Undergraduate
Term: Fall 2004
Resource type: Open educational course page

Course description:
The MIT Biology Department core courses, 7.012, 7.013, and 7.014, all cover the same core material, which includes the fundamental principles of biochemistry, genetics, molecular biology, and cell biology. Biological function at the molecular level is particularly emphasized and covers the structure and regulation of genes, as well as the structure and synthesis of proteins, how these molecules are integrated into cells, and how these cells are integrated into multicellular systems and organisms. In addition, each version of the subject has its own distinctive material.

7.012 focuses on the exploration of current research in cell biology, immunology, neurobiology, genomics, and molecular medicine.

Covered topics:
- Biochemistry
- Genetics
- Molecular Biology
- Cell Biology
- Immunology
- Neurobiology
- Genomics
- Molecular Medicine
