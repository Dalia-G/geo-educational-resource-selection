# Course: Mechanics and Materials II

Course number: 2.002
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mechanical Engineering
Academic level: Undergraduate
Term: Spring 2004
Resource type: Open educational course page

Course description:
This course provides Mechanical Engineering students with an awareness of various responses exhibited by solid engineering materials when subjected to mechanical and thermal loadings; an introduction to the physical mechanisms associated with design-limiting behavior of engineering materials, especially stiffness, strength, toughness, and durability; an understanding of basic mechanical properties of engineering materials, testing procedures used to quantify these properties, and ways in which these properties characterize material response; quantitative skills to deal with materials-limiting problems in engineering design; and a basis for materials selection in mechanical design.

Covered topics:
- Materials Science and Engineering
- Mechanical Engineering
- Solid Mechanics
