# Course: Cellular Neurobiology

Course number: 7.29J
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Biology; Brain and Cognitive Sciences
Academic level: Undergraduate
Term: Spring 2012
Resource type: Open educational course page

Course description:
This course serves as an introduction to the structure and function of the nervous system. Emphasis is placed on the cellular properties of neurons and other excitable cells. Topics covered include the structure and biophysical properties of excitable cells, synaptic transmission, neurochemistry, neurodevelopment, and the integration of information in simple systems and the visual system.

Covered topics:
- Neurobiology
- Neuroscience
- Cognitive Science
