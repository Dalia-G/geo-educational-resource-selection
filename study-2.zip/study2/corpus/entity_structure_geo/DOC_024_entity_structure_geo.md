# Course: Linear Algebra

Course number: 18.700
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Mathematics
Academic level: Undergraduate
Term: Fall 2013
Resource type: Open educational course page

Course description:
This course offers a rigorous treatment of linear algebra, including vector spaces, systems of linear equations, bases, linear independence, matrices, determinants, eigenvalues, inner products, quadratic forms, and canonical forms of matrices. Compared with 18.06 Linear Algebra, more emphasis is placed on theory and proofs.

Covered topics:
- Linear Algebra
