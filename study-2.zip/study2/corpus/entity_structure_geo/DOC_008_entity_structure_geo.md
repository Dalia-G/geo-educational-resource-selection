# Course: Database Systems

Course number: 6.830
Institution: Massachusetts Institute of Technology
Provider: MIT OpenCourseWare
Department: Electrical Engineering and Computer Science
Academic level: Graduate; Undergraduate
Term: Fall 2010
Resource type: Open educational course page

Course description:
This course relies on primary readings from the database community to introduce graduate students to the foundations of database systems, focusing on basics such as the relational algebra and data model, schema normalization, query optimization, and transactions. It is designed for students who have taken 6.033 or equivalent; no prior database experience is assumed, though students who have taken an undergraduate course in databases are encouraged to attend.

Covered topics:
- Algorithms and Data Structures
- Data Mining
- Software Design and Engineering
